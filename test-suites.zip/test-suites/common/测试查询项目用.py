# 未查询项目信息则拦截，避免无效调用
if not project_id:                                         
    print("请先点击「查询项目信息」获取项目数据")
    sys.exit()
    print('已结束')
else:
    print(f'项目ID{project_id}')
    print(f'项目名称{project_name}')
    print(f'平台ID{platform_id}')
    print(f'平台名称{platform_name}')
    print(f'多功能{multi_func}')  # 用户在输入框填什么，这里就是什么