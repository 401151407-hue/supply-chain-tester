# -*- coding: utf-8 -*-
"""企业发起续授信 - 独立脚本"""
import sys, re, random, time, requests

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"


# 从统一环境配置模块读取
from utils.environment import get_environment
env_config = get_environment(ENV)
if env_config is None:
    env_config = get_environment('SIT')
wxsbank_supplychain_partner = env_config.wxsbank_supplychain_partner
wxsbank_supplychain_web = getattr(env_config, 'wxsbank_supplychain_web', '')
wxsbank_scp_small_tool = getattr(env_config, 'wxsbank_scp_small_tool', '')
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""

if not PROJECT_ID or not CERT_NO:
    print("请先点击「查询项目信息」和「查询客户信息」后再运行")
    sys.exit()

# 从查询结果读取（需要先跑查询脚本，这里用占位）
enterpriseName = "test_enterprise"
socialCreditCode = CERT_NO
phone = "13800138000"
projectId = PROJECT_ID
partnerPlatformId = MULTI_FUNC if MULTI_FUNC else "default"

print(f"当前环境: {ENV}")
print(f"企业: {enterpriseName}")
print(f"证件号: {socialCreditCode}")
print("="*60)

# Step 1: 模拟额度临期
print("[1] 设置额度临期...")
url = f"{wxsbank_scp_small_tool}/wxsbank-scp-small-tool/risk/manMade/approve/mock/uniform/quota/limit/time/mq"
data = {"projectId":projectId,"socialCreditCode":socialCreditCode,"specifyCreditStatus":"NEAR_EXPIRED"}
r = requests.post(url=url, json=data, timeout=15)
res = r.json()
if res.get("respCode") != "10000":
    print(f"FAIL {res}")
    sys.exit()
print("OK 额度已设置为临期")

# Step 2: 联合登录
print("[2] 联合登录...")
url = f"{wxsbank_supplychain_partner}/wxsbank-supplychain-partner/user/federated/login"
data = {"partnerPlatformId":partnerPlatformId,"phone":phone,"returnUrl":"11111","urlChannelType":"02","projectId":projectId}
r = requests.post(url=url, json=data, timeout=15)
res = r.json()
if res.get("respCode") != "10000":
    print(f"FAIL {res}")
    sys.exit()
loginPath = res["body"]["loginPath"]
m = re.search(r"token=([^&]+)", loginPath)
token = m.group(1) if m else ""
print(f"OK token={token}")

# Step 3: 人脸识别-获取随机数
print("[3] 获取人脸随机数...")
headers = {"token": token}
url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/generate/flag"
data = {"name":"","idcardNo":"","timestamp":int(time.time()*1000)}
r = requests.post(url, headers=headers, json=data, timeout=15)
res = r.json()
if res.get("respCode") != "10000":
    print(f"FAIL {res}")
    sys.exit()
flag = res["body"]["flag"]
token1 = res["body"]["token"]
print(f"OK flag={flag}")

# Step 4: 查询是否借款人协助进件
print("[4] 查询进件方式...")
url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/query/assistance/entry/flag"
data = {"socialCreditCode":socialCreditCode,"projectId":projectId}
r = requests.post(url, headers=headers, json=data, timeout=15)
res = r.json()
if res.get("respCode") != "10000":
    print(f"FAIL {res}")
    sys.exit()
borrowerAssistanceEntryFlag = res["body"]["borrowerAssistanceEntryFlag"]
print(f"{'借款人协助进件' if borrowerAssistanceEntryFlag == 1 else '非借款人协助进件'}")

# Step 5: 人脸识别
print("[5] 人脸识别...")
max_retries = 10
for retry in range(max_retries):
    if borrowerAssistanceEntryFlag == 1:
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness/with/assistance/entry"
        data = {"cyType":"EDXY","flag":flag,"videoKey":"supplychain/CY/2026-03-31/202603311549477177658131774943387336.webm","socialCreditCode":socialCreditCode,"projectId":projectId,"token":token1,"timestamp":1774943388228}
    else:
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness"
        data = {"cyType":"EDXY","flag":flag,"videoKey":"supplychain/CY/2024-08-23/20240823140023282815090560.mp4","token":token1,"timestamp":int(time.time()*1000)}
    r = requests.post(url, headers=headers, json=data, timeout=15)
    res = r.json()
    if res.get("respCode") == "10000":
        cySerialNo = res["body"]["cySerialNo"]
        print(f"OK cySerialNo={cySerialNo}")
        break
    elif res.get("respCode") == "AC_0069":
        print(f"FAIL AC_0069 {res}")
        sys.exit()
    else:
        print(f"重试 {retry+1}/{max_retries}: {res}")
else:
    print(f"FAIL 连续{max_retries}次失败")
    sys.exit()

# Step 6: 提交续授信申请
print("[6] 提交续授信申请...")
max_retries = 10
for retry in range(max_retries):
    url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/grant/credit/apply/submitRenewalCredit"
    data = {"cyType":"EDXY","cySerialNo":cySerialNo,"socialCreditCode":socialCreditCode,"projectId":projectId,"timestamp":int(time.time()*1000)}
    r = requests.post(url, headers=headers, json=data, timeout=15)
    res = r.json()
    if res.get("respCode") == "10000":
        print("OK 续授信申请提交成功!")
        break
    elif res.get("respCode") == "70036":
        print(f"FAIL 存在审批中流程: {res}")
        sys.exit()
    else:
        print(f"重试 {retry+1}/{max_retries}")
else:
    print("FAIL 提交失败")
    sys.exit()

print("\n" + "="*60)
print("续授信流程完成")