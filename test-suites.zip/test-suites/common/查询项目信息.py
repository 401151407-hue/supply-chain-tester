# -*- coding: utf-8 -*-
"""查询项目信息 - 根据项目ID从数据库查询"""
import sys, re, mysql.connector
from utils.database import DB_CONFIG

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""

if not PROJECT_ID:
    print("请在上方输入项目ID")
    sys.exit()

pid = PROJECT_ID.strip()
pid = re.sub(r"\s+", "", pid)

# 用多功能参数判断是否 DEV
is_dev = MULTI_FUNC.lower() == "dev"
env_key = "DEV" if is_dev else ENV

config = DB_CONFIG.get(env_key)
if config is None:
    config = DB_CONFIG.get("SIT")
print(f">>> {env_key}环境")

try:
    conn = mysql.connector.connect(**config)
    cur = conn.cursor()
    cur.execute(
        "SELECT project_id,project_name,partner_platform_id,partner_platform_name,supply_chain_product_type,financing_percent FROM supply_chain_pimp.scp_project_info WHERE project_id = %s LIMIT 1",
        (pid,)
    )
    rows = cur.fetchall()
    if not rows:
        # 模糊搜索
        cur.execute(
            "SELECT project_id,project_name,partner_platform_id,partner_platform_name,supply_chain_product_type,financing_percent FROM supply_chain_pimp.scp_project_info WHERE project_id LIKE %s LIMIT 10",
            (f"%{pid}%",)
        )
        rows = cur.fetchall()
    if not rows:
        print(f"未匹配到项目ID: {pid}")
    elif len(rows) == 1:
        row = rows[0]
        print(f"项目ID: {row[0]}")
        print(f"项目名称: {row[1]}")
        print(f"平台ID: {row[2]}")
        print(f"平台名称: {row[3]}")
        # print(f"产品类型: {row[4]}")
        if row[5]: print(f"融资比例: {row[5]}")
    else:
        print(f"匹配到 {len(rows)} 个项目:")
        for i, row in enumerate(rows, 1):
            print(f"  {i}. ID={row[0]} 名称={row[1]} 平台={row[3]}")
    cur.close()
    conn.close()
except Exception as e:
    print(f"数据库查询失败: {e}")