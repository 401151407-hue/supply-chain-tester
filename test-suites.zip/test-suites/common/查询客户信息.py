# -*- coding: utf-8 -*-
"""查询客户信息 - 根据证件号从数据库查询"""
import sys, re, mysql.connector, requests
from utils.database import DB_CONFIG

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""

if not CERT_NO:
    print("请在上方输入证件号")
    sys.exit()

zjh = CERT_NO.strip()
zjh = re.sub(r"\s+", "", zjh)

is_dev = MULTI_FUNC.lower() == "dev"
env_key = "DEV" if is_dev else ENV
config = DB_CONFIG.get(env_key)
if config is None:
    config = DB_CONFIG.get("SIT")
print(f">>> {env_key}环境")

try:
    conn = mysql.connector.connect(**config)
    cur = conn.cursor()
    cur.execute(
        "SELECT a.enterprise_name,a.social_credit_code,a.register_phone,a.project_id,b.legal_person_name,b.idcard_no FROM supply_chain_wallet.scp_enterprise_cust_info a LEFT JOIN supply_chain_wallet.scp_enterprise_corporation_info b ON a.id=b.scp_cust_id WHERE a.social_credit_code=%s AND b.status=10 LIMIT 1",
        (zjh,)
    )
    rows = cur.fetchall()
    if rows:
        r = rows[0]
        print(f"企业名称: {r[0]}")
        print(f"企业证件号: {r[1]}")
        print(f"手机号: {r[2]}")
        print(f"项目ID: {r[3]}")
        print(f"法人姓名: {r[4]}")
        print(f"法人证件号: {r[5]}")
    else:
        # 尝试个人客户
        cur.execute(
            "SELECT user_name,idcard_no,phone_no,project_id FROM supply_chain_wallet.scp_personal_cust_info WHERE idcard_no=%s",
            (zjh,)
        )
        rows = cur.fetchall()
        if rows:
            r = rows[0]
            print(f"个人姓名: {r[0]}")
            print(f"身份证号: {r[1]}")
            print(f"手机号: {r[2]}")
            print(f"项目ID: {r[3]}")
        else:
            print(f"未匹配到证件号: {zjh}")
    cur.close()
    conn.close()
except Exception as e:
    print(f"查询失败: {e}")