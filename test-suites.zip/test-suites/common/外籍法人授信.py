# -*- coding: utf-8 -*-
"""外籍法人经办人发起授信流程"""
import sys, re, time, requests, json, random, string
from faker import Faker
from utils.random_bank_card import generate_bank_card

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""

if not PROJECT_ID:
    print("请先点击查询项目信息后再运行")
    sys.exit()

from utils.environment import get_environment
from utils.cmp_config import get_cmp_token

env_config = get_environment(ENV)
if env_config is None:
    env_config = get_environment("SIT")

wxsbank_supplychain_cmp = getattr(env_config, "wxsbank_supplychain_cmp", "")
wxsbank_supplychain_partner = env_config.wxsbank_supplychain_partner
wxsbank_supplychain_web = getattr(env_config, "wxsbank_supplychain_web", "")
wxsbank_scp_small_tool = getattr(env_config, "wxsbank_scp_small_tool", "")
cmp_login_url = getattr(env_config, "cmp_login_url", "")
projectId = PROJECT_ID

# 法人证件类型从多功能输入框读取
# 117=外国人永久居留证 119=外国护照 125=港澳通行证 126=台湾通行证
farentype_input = MULTI_FUNC.strip() if MULTI_FUNC else "119"
farentype_map = {"117":"外国人永久居留证","119":"外国护照","125":"港澳居民来往内地通行证","126":"台湾居民来往大陆通行证"}
legalPersonCertificatesType = farentype_input if farentype_input in farentype_map else "119"
farentype = farentype_map.get(legalPersonCertificatesType, "外国护照")
print(f"法人证件类型: {farentype} ({legalPersonCertificatesType})")

# 查询项目信息
from utils.database import query_db
rows = query_db(
    "SELECT project_id,project_name,partner_platform_id,partner_platform_name FROM supply_chain_pimp.scp_project_info WHERE project_id = %s LIMIT 1",
    env=ENV, params=(projectId,)
)
if not rows:
    print(f"未找到项目: {projectId}")
    sys.exit()
r = rows[0]
projectName = r[1]
partnerPlatformId = r[2]
partnerPlatformName = r[3]
print(f"项目: {projectName} 平台: {partnerPlatformName} ({partnerPlatformId})")

if projectName == "票e融":
    print("检测出该项目是票e融项目，请点击「发起票e融授信」按钮")
    sys.exit()

# 金额
try: qian = int(AMOUNT) if AMOUNT else 300000000
except ValueError: qian = 300000000

# 客户经理输入
kehjlin = MULTI_FUNC.split(",")[0].strip() if MULTI_FUNC else ""
ting = (kehjlin == "停")
feiwuxi = (kehjlin == "非无锡")

def generate_phone_number():
    prefix = random.choice(["130","131","132","133","134","135","136","137","138","139","145","147","149","150","151","152","153","155","156","157","158","159","165","166","170","171","172","173","174","175","176","177","178","180","181","182","183","184","185","186","187","188","189","191","198","199"])
    suffix = "".join(random.choice("0123456789") for _ in range(8))
    return prefix + suffix

def suijiqiyezjh():
    def generate_random_code(length, characters):
        return "".join(random.choice(characters) for _ in range(length))
    def calculate_check_digit(code):
        weights = [1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28]
        char_map = string.ascii_uppercase + string.digits
        char_values = {char: i for i, char in enumerate(char_map)}
        total = sum(char_values[code[i]] * weights[i] for i in range(17))
        check_digit_value = (31 - total % 31) % 31
        return char_map[check_digit_value]
    def generate_usci():
        dept_code = generate_random_code(1, string.ascii_uppercase + string.digits[0:9])
        category_code = generate_random_code(1, string.ascii_uppercase + string.digits[0:9])
        area_code = generate_random_code(6, string.digits)
        subject_code = generate_random_code(9, string.ascii_uppercase + string.digits)
        base_code = dept_code + category_code + area_code + subject_code
        check_digit = calculate_check_digit(base_code)
        return base_code + check_digit
    return generate_usci()


# 判断用户有没有点击将企业证件号设置为变量按钮
# ifproject() done          

# 判断是不是票e融的项目
if projectName == '票e融':
    print('检测出该项目是票e融项目，请点击「发起票e融授信」按钮')
    # msg: '提示',f'检测出该项目是票e融项目，请点击「发起票e融授信」按钮'))
    sys.exit()

# # 获取用户输入的东西
# test1 = kehjlin     
# # 判断用户需要循环造数几次
# try:
#     cishu = int(test1)
#     # print('循环造数',cishu,'次')      
# except ValueError:
#     cishu = 1

# 判断当前项目是否属于当前环境
# ifporjecta() done

# 给一个当前的循环次数，默认是0
xunhuancishu = 0
cishu = 1            
for _ in range(cishu):
    dangqianbushu = 0           # 当前步骤数，起始为0
    print(f'当前造数{xunhuancishu+1}/{cishu}次')
    # 获取用户输入的金额，判断能不能转换成int类型
    qian1 = str(qian)
    try:
        qian = int(qian1)
        print('授信金额:'+str(qian)+'分')
    except ValueError:
        qian = 300000000
        print('用户没有输入授信金额，本次默认授信金额300万')
    phone = generate_phone_number()  # 调用生成手机号函数

    fake = Faker('en_US')
    ussjname = fake.name()              # 随机美国人名                scp0096022638
    print('\n随机外国人名:'+ussjname)
    print(f'已生成随机外国人名称:{ussjname}')

    # ussjname = 'AAAAAAAAAABBBBBBBBBBCCCCCCCCCCDDDDDDDDDO'               # scp0002011778

    # 生成随机13位的外国人证件号
    prefix = random.choice(['621700','621673','623668','623094','623656','623644','621270','623667','622292','622291'
                                '622725','621522','940042','623185','623183','621005','622172','622278','621243','621298'
                                '620043','438589','620404','620602','622005','622439','621217','622271','603602','438588'])#开头
    # 后八位数字，每位都是0-9之间的随机数
    suffix = ''.join(random.choice('0123456789') for _ in range(7))#追加位数
    # 拼接前缀和后缀，形成完整的11位手机号
    uszjh = prefix + suffix  
    print(f'已生成随机外国人证件号:{uszjh}')
    print(f'已生成随机外国人证件号:{uszjh}')

    # 生成手机号            
    prefix = random.choice(['131','134','182','185'])#开头
    # 后八位数字，每位都是0-9之间的随机数
    suffix = ''.join(random.choice('0123456789') for _ in range(8))#追加位数
    # 拼接前缀和后缀，形成完整的11位手机号
    phone_number = prefix + suffix
    print(f'已生成法人随机手机号:{phone_number}')
    print(f'已生成法人随机手机号:{phone_number}')

    # 生成随机公司名称
    fake = Faker(['zh_CN'])
    sjname = fake.name()              # 随机人名
    sjqiye = sjname+fake.company()    # 随机企业
    print(f'已生成随机企业名称:{sjqiye}')

    # 生成随机企业证件号
    sjqyzjh = suijiqiyezjh()          # 随机企业证件号
    print(f'已生成随机企业证件号:{sjqyzjh}')
    print(f'已生成随机企业证件号:{sjqyzjh}')

    # 通过小工具生成企业的证件照片
    url = wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/generater/query/businessLicenseByCondition'
    json1 = {
                "name":ussjname,
                "enterpriseName":sjqiye,
                "socialCreditCode":sjqyzjh
            }
    a1 = requests.post(url=url,json=json1)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        businessLicenseKey = b1['body']['businessLicenseKey']       # 营业执照            
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 往Apollo插入企业                   scp0096022638
    url = wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/auto/deploy/meterSphere/config/saveOrUpdate'
    json = {
                "appid": "wxsbank-supplychain-web",
                "namespace": "application",
                "key": "enterprise.certification.baffle",
                "value": {sjqiye:sjqyzjh+'|'+ussjname}
            }
    requests.post(url=url,json=json)
    print('已经往Apollo插入企业挡板')
    dangqianbushu += 1
    print(f'第「{dangqianbushu}」步，已往Apollo「wxsbank-supplychain-web」插入挡板数据')

    # 开始生成一个随机经办人
    fake = Faker(['zh_CN'])
    sjjbrname = fake.name()              # 随机人名  
    print(f'已生成随机经办人名称:{sjjbrname}')
    sjsfz = fake.ssn()                # 随机身份证
    print(f'已生成经办人的身份证号:{sjsfz}')
    # 生成经办人手机号            
    prefix = random.choice(['131','134','182','185'])#开头
    # 后八位数字，每位都是0-9之间的随机数
    suffix = ''.join(random.choice('0123456789') for _ in range(8))#追加位数
    # 拼接前缀和后缀，形成完整的11位手机号
    jbrphone = prefix + suffix
    print(f'已生成经办人手机号:{jbrphone}')                
    dangqianbushu += 1
    print(f'第「{dangqianbushu}」步，已生成经办人手机号:{jbrphone}')                

    # 通过小工具生成经办人的证件照片
    url = wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/generater/query/idCardByCondition'
    json1 = {"name":sjjbrname,"idCode":sjsfz}
    a1 = requests.post(url=url,json=json1)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        idcardFrontKey = b1['body']['idcardFrontKey']       # 身份证正面
        idcardBackKey = b1['body']['idcardBackKey']         # 身份证反面
        address = b1['body']['address']
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()                


    # 开始登录后管,获取token                    scp0096022638
    token = get_cmp_token(cmp_login_url)

    headers = {"token":token}
    # 开始添加预授信白名单
    url = wxsbank_supplychain_cmp+'/wxsbank-supplychain-cmp/manage/entry/addWhitelist'
    json = {
              "guaranteeQuotaStr": "6000000",
              "guaranteeQuota": 600000000,                      # 担保额度（分）
              "preCreditQuota": 300000000,                      # 申请额度（分）
              "partnerPlatformName": partnerPlatformName,                   # 平台名称
              "partnerPlatformId": partnerPlatformId,                   # 平台Id
              "projectName": projectName,                      # 项目名称
              "enterpriseName": sjqiye,
              "socialCreditCode": sjqyzjh,
              "projectId": projectId,
              "preCreditQuotaStr": "3000000"
            }
    a1 = requests.post(url,headers=headers,json=json)       # scp0096022638
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('预授信白名单添加成功')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 获取客户经理输入框输入内容
    test = kehjlin
    # 将获取到的客户经理的值去除所有空格
    test = test.strip()
    test = re.sub(r'\s+', '', test).strip()
    if test == '117':
        print('用户输入117，本次法人证件类型为外国人永久居留证')
        legalPersonCertificatesType = '117'
        farentype = '外国人永久居留证'
    elif test == '119':
        print('用户输入119，本次法人证件类型为外国护照')
        legalPersonCertificatesType = '119'
        farentype = '外国护照'
    elif test == '125':
        print('用户输入125，本次法人证件类型为港澳居民来往内地通行证')
        legalPersonCertificatesType = '125'
        farentype = '港澳居民来往内地通行证'
    elif test == '126':
        print('用户输入126，本次法人证件类型为台湾居民来往大陆通行证')
        legalPersonCertificatesType = '126'
        farentype = '台湾居民来往大陆通行证'
    else:
        print('用户没有指定法人证件类型，本次默认为外国护照')
        legalPersonCertificatesType = '119'
        farentype = '外国护照'                                        
    # time.sleep(30)
    # 从后管新增协助借款人进件-添加外籍法人
    url = wxsbank_supplychain_cmp+'/wxsbank-supplychain-cmp/manage/entry/assist/borrower/add'
    json = {
              "legalPersonPhone": phone_number,                # 法人手机号码
              "agentName": sjjbrname,                                # 经办人姓名
              "legalPersonResidenceAddress": "我住在这里",
              "legalPersonCertificatesType": legalPersonCertificatesType,             # 法人证件类型
              "legalPersonGender":"2",                                                  # 外籍法人性别 1-男 2-女
              "socialCreditCode": sjqyzjh,         # 统一社会信用代码
              "legalPersonBirth": "1990-01-01",
              "legalPersonActiveStartDate": "2000-01-01",
              "legalPersonIdcardFrontPath": "blob:http://10.100.8.11:1901/aeefab76-2ad3-411e-807a-87631798d68d",
              "legalPersonName": ussjname,                      # 法人名称
              "legalPersonIdcardFrontKey": "supplychain/APPROVEMATERIAL/2026-03-25/17744265432260170560019冯一巧反面.jpg",
              "legalPerson": ussjname,                    # 法定代表人
              "legalPersonIdcardBackKey": "",
              "_socialCreditCode": sjqiye,
              "agentCertificatesType": "101",
              "agentCertificatesNo": sjsfz,          # 经办人证件号码
              "legalPersonCertificatesNo": uszjh,         # 法人证件号码
              "legalPersonActiveEndDate": "9999-12-31",
              "projectId": projectId,                         # 项目ID
              "enterpriseName": sjqiye,              # 企业名称
              "legalPersonIdcardBackPath": "",
              "legalPersonNationalityCode": "TCD",                  # 国籍代码
              "attachedFile": [
                {
                  "fileName": "供应链系统业务办理授权书.jpg",
                  "filePath": "http://10.100.8.11:9000/private-bucket/supplychain/ORDER/2026-03-25/17744266572130170560022%E4%BE%9B%E5%BA%94%E9%93%BE%E7%B3%BB%E7%BB%9F%E4%B8%9A%E5%8A%A1%E5%8A%9E%E7%90%86%E6%8E%88%E6%9D%83%E4%B9%A6.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=private-bucket%2F20260325%2Fdefault%2Fs3%2Faws4_request&X-Amz-Date=20260325T081737Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=2c00e3a306fc0eb78de5127d457910c7187b4a019c8cb49f9f36b1ff870c8829",
                  "fileKey": "supplychain/ORDER/2026-03-25/17744266572130170560022供应链系统业务办理授权书.jpg",
                  "fileType": "0006"
                },
                {
                  "fileName": "吴素珍正面.jpg",
                  "filePath": "http://10.100.8.11:9000/private-bucket/supplychain/ORDER/2026-03-25/17744265340860170560018%E5%90%B4%E7%B4%A0%E7%8F%8D%E6%AD%A3%E9%9D%A2.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=private-bucket%2F20260325%2Fdefault%2Fs3%2Faws4_request&X-Amz-Date=20260325T081534Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=48399ab80dc64f4da5faa97593e8d4d96c9898d574f3c6006f02ae1d4173f1a7",
                  "fileKey": "supplychain/ORDER/2026-03-25/17744265340860170560018吴素珍正面.jpg",
                  "fileType": "9999"
                },
                {
                  "fileName": "法人正脸照片.jpg",
                  "filePath": "http://10.100.8.11:9000/private-bucket/supplychain/ORDER/2026-03-25/17744266329410170560020%E6%B3%95%E4%BA%BA%E6%AD%A3%E8%84%B8%E7%85%A7%E7%89%87.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=private-bucket%2F20260325%2Fdefault%2Fs3%2Faws4_request&X-Amz-Date=20260325T081713Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=cccedb5e8567fcf44feecc63722e9b22c98b024cb60e6ef375a9681076e45187",
                  "fileKey": "supplychain/ORDER/2026-03-25/17744266329410170560020法人正脸照片.jpg",
                  "fileType": "2001"
                },
                {
                  "fileName": "法人手持证件照.jpg",
                  "filePath": "http://10.100.8.11:9000/private-bucket/supplychain/ORDER/2026-03-25/17744266400800170560021%E6%B3%95%E4%BA%BA%E6%89%8B%E6%8C%81%E8%AF%81%E4%BB%B6%E7%85%A7.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=private-bucket%2F20260325%2Fdefault%2Fs3%2Faws4_request&X-Amz-Date=20260325T081720Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=1492ecbe803333da9444d7b328756394fe7a820b9d65f33c127a59b29e3cc8ae",
                  "fileKey": "supplychain/ORDER/2026-03-25/17744266400800170560021法人手持证件照.jpg",
                  "fileType": "2002"
                }
              ]
            }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('后管已新增协助借款人进件成功\n')
        # print('*'*20+f'{ussjname}'+'*'*20)
        # print(f'企业名称:{sjqiye}')
        # print(f'企业证件号:{sjqyzjh}')
        # print(f'法人名称:{ussjname}')
        # print(f'法人证件号:{uszjh}')
        # print(f'法人手机号:{phone_number}')
        # print(f'经办人名称:{sjjbrname}')
        # print(f'经办人证件号:{sjsfz}')
        # print(f'经办人手机号:{jbrphone}')
        # print('*'*50)
        # # msg: '提示','外籍法人后管部分准备完毕'))
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # mock天眼查数据提交
    print('开始mock天眼查数据提交 /wxsbank-scp-small-tool/mock/tian/yan/info/submit')
    # 判断用户在「客户经理」输入框是否有输入「非无锡」，非无锡的话，则不需要采集授权书
    if kehjlin == '非无锡':
        regLocation = '北京市朝阳区朝阳公园南路1号相亲角'
        print('用户输入「非无锡」，本期mock企业地址为「北京市朝阳区朝阳公园南路1号相亲角」')
    else:
        regLocation = '江苏省无锡市锡山区东翔路5781号'
    url = wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/mock/tian/yan/info/submit'
    json = {
              "regStatus": "存续",
              "regCapital": 42000000,
              "city": "南通市",
              "categoryBig": "黑色金属冶炼和压延加工业",
              "industry": "制造业",
              "staffNum": 3,
              "bondName": "",
              "socialCreditCode": sjqyzjh,
              "operateStartDate": "2011-05-02",
              "legalPersonName": ussjname,
              "legalPersonType": 1,
              "regNumber": sjqyzjh,
              "province": "",
              "fromTime": "1999-01-01",
              "actualCapitalCurrency": "欧元",
              "alias": "伟达",
              "companyOrgType": "其他股份有限公司（上市）",
              "orgNumber": "MA6PFCNP6",
              "enterpriseName": sjqiye,
              "toTime": "9999-01-01",
              "actualCapital": 1000000,
              "categoryMiddle": "钢压延加工",
              "regInstitute": "无锡市市场监督管理局",
              "businessScope": "1货运代理、国际货物运输代理；普通货物道路运输、冷藏车道路运输、集装箱道路运输；货运配载；搬运装卸；普通货物仓储服务（ 不含危险化学品）； 物流方案的设计与策划； 汽车租赁； 汽车修理与维护； 建筑工程劳务与分包； 商务信息咨询；承办会议及商品展览展示活动； 汽车、 仪器仪表、 五金交电、 汽车、 摩托车配件、 其他机械设备及电子产品、 日用百货的销售。（ 依法须经批准的项目， 经相关部门批准后方可开展经营活动） ",
              "taxNumber": sjqyzjh,
              "regLocation": regLocation,   # 根据这个字段判断是否是无锡企业
              "establishDate": "1970-06-11",
              "regCapitalCurrency": "人民币",
              "enterpriseType": "01",
              "categorySmall": "钢压延加工",
              "tags": "",
              "approvedDate": "1970-06-11",
              "district": "如东县",
              "bondType": "",
              "operateEndDate": "2222-05-08",
              "category": "制造业",
              "isMicroEnt": 0
            }
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    print(url)
    print(json)
    if b1['respCode'] == str(10000):                    
        print('mock天眼查数据已提交')
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，已提交mock数据，公司地址为「{regLocation}」')                
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit() 
    # JBRcustomer() done via UI
    # 获取客户经理输入框输入内容
    test = kehjlin
    # 将获取到的客户经理的值去除所有空格
    test = test.strip()
    test = re.sub(r'\s+', '', test).strip()
    if test == '停':
        print("[停] 当前节点为已配置好Apollo挡板以及添加完后管名单")
        result = input("是否继续? (yes/no): ").strip()
        if result == "yes":
            print("流程继续")
        elif result == "no":
            print("流程终止")
            print(farentype+'*'*20+f'{ussjname}'+'*'*20)
            print(f'企业名称:{sjqiye}')
            print(f'企业证件号:{sjqyzjh}')
            print(f'法人名称:{ussjname}')
            print(f'法人证件号:{uszjh}')
            print(f'法人手机号:{phone_number}')
            print(f'经办人名称:{sjjbrname}')
            print(f'经办人证件号:{sjsfz}')
            print(f'经办人手机号:{jbrphone}')
            # print('经办人免密登录地址:',mianmidenglu)
            # print('法人免密登录地址:',mianmidenglu1)
            print('*'*50)
            print(farentype+'*'*20+f'{ussjname}'+'*'*20)
            print(f'企业名称:{sjqiye}')
            print(f'企业证件号:{sjqyzjh}')
            print(f'法人名称:{ussjname}')
            print(f'法人证件号:{uszjh}')
            print(f'法人手机号:{phone_number}')
            print(f'经办人名称:{sjjbrname}')
            print(f'经办人证件号:{sjsfz}')
            print(f'经办人手机号:{jbrphone}')
            print('*'*50)
            sys.exit()   

        
    # 使用经办人手机号联合登录
    url = wxsbank_supplychain_partner+'/wxsbank-supplychain-partner/user/federated/login'
    json = {"partnerPlatformId":partnerPlatformId,"phone":jbrphone,"returnUrl":"11111","urlChannelType":"02","projectId":projectId}
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        token = b1['body']['loginPath']                     # 获取返回参数里面的整段url，包含token的
        mianmidenglu = b1['body']['loginPath']                     # 获取返回参数里面的整段url，包含token的                    
        loginlogin = b1['body']['loginPath']              # 用来导出文件用的
        print('免密登录地址:',token)                    
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，已获取免密登录地址:{token}')
        token = re.search(r'token=([^&]+)', token).group(1) # 正则表达式单独提取token        
        print('提取token:',token)                    
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()   

    # 身份证正面识别
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/user/idcard/front/identify'
    json = {
              "idcardFrontKey": idcardFrontKey,
              "projectId": projectId,
              "timestamp": 1773043936048
            }
    headers = {"token":token}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        address = b1['body']['address']
        print(f'已解析address「{address}」')
        area = b1['body']['area']
        print(f'已解析area「{area}」')
        city = b1['body']['city']
        print(f'已解析city「{city}」')
        detailedAddress = b1['body']['detailedAddress']
        print(f'已解析detailedAddress「{detailedAddress}」')
        idcardFrontOcrSerialNo = b1['body']['idcardFrontOcrSerialNo']
        print(f'已解析idcardFrontOcrSerialNo「{idcardFrontOcrSerialNo}」')  
        idcardNo = b1['body']['idcardNo']
        print(f'已解析idcardNo「{idcardNo}」')
        province = b1['body']['province']
        print(f'已解析province「{province}」')
        userBirth = b1['body']['userBirth']
        print(f'已解析userBirth「{userBirth}」')   
        userName = b1['body']['userName']
        print(f'已解析userName「{userName}」')
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，身份证正面已识别成功')                     
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 身份证反面识别
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/user/idcard/back/identify'
    json = {
              "idcardBackKey": idcardBackKey,
              "idcardNo": idcardNo,
              "projectId": projectId,
              "timestamp": 1773045327446
            }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        certificateIssuAuthority = b1['body']['certificateIssuAuthority']
        print(f'已解析certificateIssuAuthority「{certificateIssuAuthority}」')   
        effectiveDate = b1['body']['effectiveDate']
        print(f'已解析effectiveDate「{effectiveDate}」')  
        expirationDate = b1['body']['expirationDate']
        print(f'已解析expirationDate「{expirationDate}」')  
        idcardBackOcrSerialNo = b1['body']['idcardBackOcrSerialNo']
        print(f'已解析idcardBackOcrSerialNo「{idcardBackOcrSerialNo}」')     
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，身份证反面已识别成功')     
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 身份证信息上传
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/user/idcard/uploadV2'
    json = {
              "idcardBackKey": idcardBackKey,
              "idcardFrontOcrSerialNo": idcardFrontOcrSerialNo,
              "idcardFrontKey": idcardFrontKey,
              "expiredDate": expirationDate,
              "taxCitizen": "0",
              "userName": userName,
              "idcardBackOcrSerialNo": idcardBackOcrSerialNo,
              "projectId": projectId,
              "certificatesNo": idcardNo,
              "effectiveDate": effectiveDate,
              "residenceAddress": detailedAddress,
              "timestamp": 1773045536587
            }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，身份证信息上传成功')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 人脸识别-获取随机数(需token)
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/generate/flag'
    json = {
            "name": userName,
            "idcardNo": idcardNo,
            "timestamp": 1773046635840
          }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        flag = b1['body']['flag']
        print(f'已提取flag「{flag}」')
        token1 = b1['body']['token']
        print(f'已提取token「{token1}」')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 获取场景下的协议列表
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocolList/query'
    json = {"screenType":"20","projectId":projectId,"timestamp":1773046636076}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for fileName in b1['body']['protocolList']:
            if fileName['fileName'] == '《无锡锡商银行人脸信息采集授权书》':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/query'
                json = {"name":userName,"idcardNo":idcardNo,"timestamp":1773102943237}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    fileName = b1['body']['fileName']
                    print(f'已预览完{fileName}')
                    dangqianbushu += 1
                    print(f'第「{dangqianbushu}」步，已预览完{fileName}')
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 人脸识别
    max_retries = 10  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
    # 人脸识别-获取随机数(需token)
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/generate/flag'
        json = {
                "name": userName,
                "idcardNo": idcardNo,
                "timestamp": 1773046635840
              }
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            flag = b1['body']['flag']
            print(f'已提取flag「{flag}」')
            token1 = b1['body']['token']
            print(f'已提取token「{token1}」')
        else:
            print('\n'+'*'*100)
            print(url)
            print(b1)
            print('*'*100+'\n')
            # msg: '提示',b1))
            sys.exit()
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/video/liveness'
        json = {
                  "cyType": "SMRZ",
                  "flag": flag,
                  "videoKey": "supplychain/CY/2026-03-10/20260310135446974700767abe1bf27c6a991382d5f7da3d7680e29.mov",
                  "token": token1,
                  "timestamp": 1773122088023
                }
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            cySerialNo = b1['body']['cySerialNo']
            print(f'提取cySerialNo「{cySerialNo}」')
            dangqianbushu += 1
            print(f'第「{dangqianbushu}」步，人脸识别已提取{cySerialNo}')
            break
        else:
            retry_count += 1
            print(f'第「{retry_count}/{max_retries}」次人脸识别失败，重试中……')
    if retry_count == max_retries:
        print(f'连续{retry_count}次人脸识别失败，测试终止')
        print('\n',url)
        print('请求头:',headers)
        print('入参:',json)
        print('响应:',b1,'\n')
        # msg: '警告',f'连续{retry_count}次人脸识别失败，流程终止'))
        sys.exit()

    # 签署《无锡锡商银行人脸信息采集授权书》异步                
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/signatrue'
    json = {"name":userName,"idcardNo":idcardNo,"timestamp":1773122096319}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('已签署完《无锡锡商银行人脸信息采集授权书》')
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，已签署完《无锡锡商银行人脸信息采集授权书》')     
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 用户信息实名认证
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/user/idcard/face/identification/auth'
    json = {"cyType":"SMRZ","cySerialNo":cySerialNo,"projectId":projectId,"timestamp":1773122096366}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('已完成实名认证')
        dangqianbushu += 1
        print(f'第「{dangqianbushu}」步，已完成实名认证')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()


    # # msg: "提示", "点击确定后继续")
    # sys.exit()

    # 企业认证-天眼查：根据企业名称模糊查询企业信息
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/query/cust/by/sky/eye'
    json = {"enterpriseName":sjqiye,"timestamp":1773123512333}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for enterpriseName1 in b1['body']:
            if enterpriseName1['enterpriseName'] == sjqiye:
                print(f'已从企业下拉列表中查询到企业「{sjqiye}」')
                break
            else:
                print('\n'+'*'*100)
                print(f'从企业下拉列表中没有查询到「{sjqiye}」，意味着Apollo挡板被删了，去检查一下')
                print(url)
                print(b1)
                print('*'*100+'\n')
                # msg: '提示',b1))
                sys.exit()  
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit() 
        
    # 获取协议列表
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocolList/query'
    json = {"screenType":"04","socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1773124481492}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for protocolList in b1['body']['protocolList']:
            # 《无锡锡商银行个人信息查询及使用授权书》
            if protocolList['templateCode'] == 'GRXXCJ001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/information/collect/personal/query'
                json = {"fileName":protocolList['fileName'],"screenType":"04","projectId":projectId,"legalPersonName":ussjname}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()
            # 《纳税人自证声明》
            elif protocolList['templateCode'] == 'JGSSJMSFSM':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/taxpayer/query'
                json = {"fileName":protocolList['fileName'],"screenType":"04","custName":sjqiye,"socialCreditCode":sjqyzjh}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()
            # 《企业信息采集使用授权书》
            elif protocolList['templateCode'] == 'QYXXCJ001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/information/collect/enterprise/query'
                json = {"screenType":"04","custName":sjqiye,"socialCreditCode":sjqyzjh}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()  
            # 《个人征信查询及报送授权书》
            elif protocolList['templateCode'] == 'GRZXSQS001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/power/attorney/credit/query'
                json = {"fileName":protocolList['fileName'],"screenType":"04"}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()
            # 《企业征信查询及报送授权书》
            elif protocolList['templateCode'] == 'QYZXSQS001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/letter/author/ization/query'
                json = {"screenType":"04","socialCreditCode":sjqyzjh,"enterpriseName":sjqiye}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                #
                # print(b1)
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()    

            # 《无锡锡商银行电子交易账簿管理协议》
            elif protocolList['templateCode'] == 'DZZHGLXY001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/ebook/query'
                json = {"screenType":"04","socialCreditCode":sjqyzjh,"enterpriseName":sjqiye}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()    

            # 《授信业务申请书》
            elif protocolList['templateCode'] == 'SXYESQS001':
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/credit/business/apply/query'
                json = {"screenType":"04","projectId":projectId,"socialCreditCode":sjqyzjh}
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()

            # 《CFCA数字服务协议》
            else:
                url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/view/common/contract'
                json = {
                          "queryJson": {
                            "partyName": sjqiye,
                            "enterpriseName": sjqiye
                          },
                          "screenType": "04",
                          "templateCode": protocolList['templateCode'],
                          "socialCreditCode": sjqyzjh,
                          "enterpriseName": sjqiye,
                          "projectId": projectId,
                          "timestamp": 1773121840223
                        }
                a1 = requests.post(url,headers=headers,json=json)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f"已预览{b1['body']['fileName']}")
                    dangqianbushu += 1
                    print(f"第「{dangqianbushu}」步，已预览{b1['body']['fileName']}")
                else:
                    print('\n'+'*'*100)
                    print(url)
                    print(b1)
                    print('*'*100+'\n')
                    # msg: '提示',b1))
                    sys.exit()

    # 人脸识别-获取随机数(需token)
    # url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/generate/flag'
    # json = {"name":"","idcardNo":"","timestamp":1773285652827}
    # a1 = requests.post(url,headers=headers,json=json)
    # b1 = a1.json()
    # if b1['respCode'] == str(10000):
    #     flag = b1['body']['flag']
    #     print(f'已解析flag「{flag}」')
    #     token1 = b1['body']['token']
    #     print(f'已解析token「{token1}」')
    # else:
    #     print('\n'+'*'*100)
    #
    #     print(url)
    #     print(b1)
    #     print('*'*100+'\n')
    #     # msg: '提示',b1))
    #     sys.exit()

    max_retries = 10  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 人脸识别-获取随机数(需token)
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/generate/flag'
        json = {"name":"","idcardNo":"","timestamp":1773285652827}
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            flag = b1['body']['flag']
            print(f'已解析flag「{flag}」')
            token1 = b1['body']['token']
            print(f'已解析token「{token1}」')
        else:
            print('\n'+'*'*100)
            print(url)
            print(b1)
            print('*'*100+'\n')
            # msg: '提示',b1))
            sys.exit()

        # 人脸识别
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/video/liveness'
        json = {
                  "cyType": "SMRZ",
                  "flag": flag,
                  "videoKey": "supplychain/CY/2026-03-12/20260312112826950852967abe1bf27c6a991382d5f7da3d7680e29.mov",
                  "token": token1,
                  "timestamp": 1773286107189
                }
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            cySerialNo = b1['body']['cySerialNo']
            print(f'已上传人脸识别视频，获取返回cySerialNo「{cySerialNo}」')
            break
        else:
            retry_count += 1
            print(b1)
            print(f'当前第「{retry_count}/{max_retries}」次人脸识别失败，重试中……')
    if retry_count == max_retries:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    max_retries = 10  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:            
        # 企业认证-企业信息上传
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/info/upload'
        json = {
                  "cyType": "SMRZ",
                  "selfProofFlag": "0",
                     "legalPersonInfo": {
                          "idcardFrontKey": "supplychain/APPROVEMATERIAL/2026-03-25/17743985830750170560040马茂东反面.jpg",
                          "expiredDate": "9999-12-31",
                          "name": ussjname,
                          "idcardNo": uszjh,
                          "phoneNo": phone_number,
                          "effectiveDate": effectiveDate,
                          "residenceAddress": "1111"
                        },                              
                  "cySerialNo": cySerialNo,
                  "userName": ussjname,                     # 法人名称
                  "userRole": "104",                        # 操作人用户角色 100:法定代表人,104:经办人,200:普通用户,9990:业务控制人,9991:追加担保人
                  "socialCreditCode": sjqyzjh,
                  "enterpriseName": sjqiye,
                  "projectId": projectId,
                  "timestamp": 1773286111169
                }
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            grantCreditApplyNo = b1['body']['grantCreditApplyNo']
            userRole = b1['body']['userRole']                # 操作人用户角色 100:法定代表人,104:经办人,200:普通用户,9990:业务控制人,9991:追加担保人
            print(f'「{sjqiye}」企业认证已通过，已提取授信申请编号「{grantCreditApplyNo}」')
            dangqianbushu += 1
            print(f"第「{dangqianbushu}」步，「{sjqiye}」企业认证已通过，已提取授信申请编号「{grantCreditApplyNo}」")
            break
        else:
            retry_count += 1
            print(f'企业信息认证失败次数「{retry_count}/{max_retries}」，尝试继续上传……')
    if retry_count == max_retries:
        print(f'连续{retry_count}次企业信息认证失败，测试终止')
        print('\n',url)
        print('请求头:',headers)
        print('入参:',json)
        print('响应:',b1,'\n')
        # msg: "警告", f'连续{retry_count}次企业信息认证失败，测试终止'))
        sys.exit()
    
    print(farentype+'*'*20+f'{ussjname}'+'*'*20)
    print(f'企业名称:{sjqiye}')
    print(f'企业证件号:{sjqyzjh}')
    print(f'法人名称:{ussjname}')
    print(f'法人证件号:{uszjh}')
    print(f'法人手机号:{phone_number}')
    print(f'经办人名称:{sjjbrname}')
    print(f'经办人证件号:{sjsfz}')
    print(f'经办人手机号:{jbrphone}')
    print(f'免密登录地址:{mianmidenglu}')
    print('*'*50)
    print(farentype+'*'*20+f'{ussjname}'+'*'*20)
    print(f'企业名称:{sjqiye}')
    print(f'企业证件号:{sjqyzjh}')
    print(f'法人名称:{ussjname}')
    print(f'法人证件号:{uszjh}')
    print(f'法人手机号:{phone_number}')
    print(f'经办人名称:{sjjbrname}')
    print(f'经办人证件号:{sjsfz}')
    print(f'经办人手机号:{jbrphone}')
    print('免密登录地址:',mianmidenglu)
    print('*'*50)
    # # msg: "提示", f'H5流程已经走到给法人发送短信进行人脸识别环节，后续请手动操作'))


    # 给法定代表人发送短信
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/entry/auth/sms'
    json = {"grantCreditApplyNo":grantCreditApplyNo,"timestamp":1774442283684}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        smsAuthLink = b1['body']['smsAuthLink']
        print(f'已向法人发送短信:{smsAuthLink}')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 获取客户经理输入框输入内容
    test = kehjlin
    # 将获取到的客户经理的值去除所有空格
    test = test.strip()
    test = re.sub(r'\s+', '', test).strip()
    if test == '停':
        print("[停] 当前节点为已给法人发送短信")
        result = input("是否继续? (yes/no): ").strip()
        if result == "yes":
            print("流程继续")
        elif result == "no":
            print("流程终止")
            sys.exit()                     

    # 获取重定向前的响应
    response = requests.get(smsAuthLink, allow_redirects=False)

    # 获取 Location 响应头
    location_url = response.headers.get('Location')
    print(f"完整URL: {location_url}")

    # 提取 grantCreditApplyNo
    if 'grantCreditApplyNo=' in location_url:
        grantCreditApplyNo = location_url.split('grantCreditApplyNo=')[1].split('&')[0]
        print(f"申请编号: {grantCreditApplyNo}")                    
    # 合同份数 
    hetongnum = 0
    # 接口: 查询授信授权协议列表
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/enterprise/entry/auth/protocol/list/query'
    json = {"grantCreditApplyNo":grantCreditApplyNo,"timestamp":1774442585067}
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for protocolList in b1['body']['protocolList']:
            # print(protocolList['fileName'])
            templateCode = protocolList['templateCode']
            url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/enterprise/entry/auth/protocol/preview'
            json = {
                      "grantCreditApplyNo": grantCreditApplyNo,
                      "queryJson": {
                        "enterpriseName": sjqiye
                      },
                      "templateCode": templateCode,
                      "timestamp": 1774485325276
                    }
            a1 = requests.post(url=url,json=json)
            b1 = a1.json()
            print(b1)
            if b1['respCode'] == str(10000):
                hetongnum += 1
                # fileName = b1['body']['fileName']
                # print(f'第「{hetongnum}」份合同，已预览完{fileName}')
    else:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()   

    # 经办人进件授权法定代表人静默注册
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/enterprise/entry/auth/register'  
    json = {"grantCreditApplyNo":grantCreditApplyNo,"timestamp":1774487278315}
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):  
        print('经办人进件授权法定代表人静默注册成功')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 人脸识别-查询是否是借款人协助进件（无token）
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/query/assistance/entry/flag'
    json = {
              "cyType": "JBRGCF",
              "grantCreditApplyNo": grantCreditApplyNo,
              "isApplyNo": "0",
              "socialCreditCode": sjqyzjh,
              "projectId": projectId,
              "timestamp": 1774487278784
            }   
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):  
        pass
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 人脸识别-获取随机数(免登录)
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/flag'
    json = {"grantCreditApplyNo":grantCreditApplyNo,"timestamp":1774487279090}    
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):  
        flag = b1['body']['flag']
        token1 = b1['body']['token']
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 获取场景下的协议列表
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocolList/query'
    json = {"screenType":"20","projectId":projectId,"timestamp":1774487279298}
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for protocolList in b1['body']['protocolList']:
            templateCode = protocolList['templateCode']
            # 预览《无锡锡商银行人脸信息采集授权书》
            url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/query'
            json = {"name":ussjname,"idcardNo":uszjh,"timestamp":1774488654587}
            a1 = requests.post(url=url,json=json)
            b1 = a1.json()
            if b1['respCode'] == str(10000):
                fileName = b1['body']['fileName']
                print(f'已预览完{fileName}')
            else:              
                print('\n'+'*'*100)
                print(url)
                print(b1)
                print('*'*100+'\n')
                # msg: '提示',b1))
                sys.exit()                                                                
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    max_retries = 10  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 人脸识别-借款人协助进件（无token）
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/video/liveness/with/assistance/entry'
        json = {
                  "cyType": "JBRGCF",                           # 非法人授信进件-法定代表人签署协议
                  "flag": flag,
                  "videoKey": "supplychain/CY/2026-03-26/20260326093851550853859abe1bf27c6a991382d5f7da3d7680e29.mov",
                  "grantCreditApplyNo": grantCreditApplyNo,     # 授信进件申请流水号
                  "socialCreditCode": sjqyzjh,                  # 统一社会信用代码
                  "projectId": projectId,
                  "token": token1 ,
                  "timestamp": 1774489131895
                }     
        a1 = requests.post(url=url,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            cySerialNo = b1['body']['cySerialNo']
            print(f'提取参数cySerialNo「{cySerialNo}」')
            break
        else:
            retry_count += 1
            print(b1)
            print(f'当前第「{retry_count}/{max_retries}」次人脸失败，重试中……')
    if retry_count == max_retries:
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 签署《无锡锡商银行人脸信息采集授权书》异步
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/signatrue'
    json = {"name":ussjname,"idcardNo":sjqyzjh,"timestamp":1774489136378}  
    a1 = requests.post(url=url,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('签署《无锡锡商银行人脸信息采集授权书》异步成功')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()       
    max_retries = 10  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:                    
        # 非法人进件:法定代表人授权提交
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/free/login/grant/auth/apply/submit'
        json = {
                  "cyType": "JBRGCF",
                  "grantCreditApplyNo": grantCreditApplyNo,
                  "cySerialNo": cySerialNo,
                  "projectId": projectId,
                  "timestamp": 1774489598565
                }  
        a1 = requests.post(url=url,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            print('提交授信申请成功')
            break
        else:
            retry_count += 1
            print(f'第「{retry_count}/{max_retries}」次提交授信失败，重试中……')
            time.sleep(5)
        if retry_count == max_retries:       
            print('\n'+'*'*100)
            print(url)
            print(b1)
            print('*'*100+'\n')
            # msg: '提示',b1))
            sys.exit()     
    # 使用法人手机号联合登录
    max_retries = 5  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        url = wxsbank_supplychain_partner+'/wxsbank-supplychain-partner/user/federated/login'
        json = {"partnerPlatformId":partnerPlatformId,"phone":phone_number,"returnUrl":"11111","urlChannelType":"02","projectId":projectId}
        a1 = requests.post(url=url,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            mianmidenglu1 = b1['body']['loginPath']                     # 获取免密登录地址
            token = re.search(r'token=([^&]+)', mianmidenglu1).group(1) # 正则表达式单独提取token
            break
        else:
            retry_count += 1
            print(b1['respMsg'])
            time.sleep(3)  
    if retry_count == max_retries:
        print(f'连续{retry_count}次使用法人手机号获取免密登录地址失败')
        print('\n',url)
        print('请求头:',headers)
        print('入参:',json)
        print('响应:',b1,'\n')
        print(farentype+'*'*20+f'{ussjname}'+'*'*20)
        print(f'企业名称:{sjqiye}')
        print(f'企业证件号:{sjqyzjh}')
        print(f'法人名称:{ussjname}')
        print(f'法人证件号:{uszjh}')
        print(f'法人手机号:{phone_number}')
        print(f'经办人名称:{sjjbrname}')
        print(f'经办人证件号:{sjsfz}')
        print(f'经办人手机号:{jbrphone}')
        print('经办人免密登录地址:',mianmidenglu)
        print('*'*50)
        # msg: "提示", f'授信申请已提交成功'))
        sys.exit()
    # # JBRcustomer() done via UI                    

    # # msg: "提示", f'授信申请已提交成功'))
    
    # 获取客户经理输入框输入内容
    test = kehjlin
    # 将获取到的客户经理的值去除所有空格
    test = test.strip()
    test = re.sub(r'\s+', '', test).strip()
    if test == '停':
        print("[停] 当前节点为已提交授信申请，但是还未进行资料采集")
        result = input("是否继续? (yes/no): ").strip()
        if result == "yes":
            print("流程继续")
        elif result == "no":
            print("流程终止")
            sys.exit()

    headers = {"token":token}
    # 人脸识别-获取活体检测版本
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/cyIdentify/generate/getVersion'
    json = {"projectId":projectId,"timestamp":1774871140531}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        version = b1['body']['version']
        if version == '1':
            print('当前人脸识别版本为「唇语」')
        elif version == '2':
            print('当前人脸识别版本为「动作」')
        elif version == '3':
            print('当前人脸识别版本为「腾讯人脸识别」')
        else:
            print(f'当前人脸识别版本未知「version={version}」')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()


    # 查询企业钱包和授信状态
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/query/queryWalletAndCreditInfo'
    json = {"socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1774871141181}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        enterpriseAuditStatus = b1['body']['enterpriseAuditStatus']         # 00:未审批（待审批）,01:审批中,02:审批通过
        if enterpriseAuditStatus == '00':
            print(f'客户信息状态处于{enterpriseAuditStatus}未审批（待审批）')
        elif enterpriseAuditStatus == '01':
            print(f'客户信息状态处于{enterpriseAuditStatus}审批中')
        elif enterpriseAuditStatus == '02':
            print(f'客户信息状态处于{enterpriseAuditStatus}审批通过')
        else:
            print(f'客户信息状态处于未知{enterpriseAuditStatus}')    
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit() 


    # sys.exit()
    # 资料采集:查询节点状态及流水 
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/collect/stage/query'
    json = {"socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1774872738563}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        enterpriseCollectSerialNo = b1['body']['enterpriseCollectSerialNo']     # 资料采集流水号
        status = b1['body']['status']                                           # 资料采集节点状态
        if status == '00':
            print('当前资料采集节点为营业执照采集')
        elif status == '01':
            print('当前资料采集节点为关联人采集')
        elif status == '03':
            print('当前资料采集节点为打款验证')
        elif status == '04':
            print('当前资料采集节点为设置密码')
        elif status == '05':
            print('当前资料采集节点为资料采集完成')
        elif status == '06':
            print('当前资料采集节点为上送中台客户信息')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 查询营业执照信息
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/license/provisionalData'
    json = {"socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1774872739013}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        pass
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 识别企业营业执照
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/license/identify'                                            
    json = {
              "businessLicenseKey": businessLicenseKey,
              "skipDataCheck": True,
              "timestamp": 1774873135765
            }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        area = b1['body']['area']
        authSerialNo = b1['body']['authSerialNo']
        businessLicenseKey = b1['body']['businessLicenseKey']
        businessScope = b1['body']['businessScope']
        city = b1['body']['city']
        detailedAddress = b1['body']['detailedAddress']
        effectiveDate = b1['body']['effectiveDate']
        enterpriseCategory = b1['body']['enterpriseCategory']
        enterpriseName = b1['body']['enterpriseName']
        establishDate = b1['body']['establishDate']
        expirationDate = b1['body']['expirationDate']
        legalPersonName = b1['body']['legalPersonName']
        province = b1['body']['province']
        regAuthority = b1['body']['regAuthority']
        regDate = b1['body']['regDate']
        region = b1['body']['region']
        registerCapital = b1['body']['registerCapital']
        registerNo = b1['body']['registerNo']
        socialCreditCode = b1['body']['socialCreditCode']
        print('已成功解析营业执照')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()  

    max_retries = 5  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 资料采集:上传企业营业执照信息
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/license/upload/collect'
        json = {
                  "enterpriseCollectSerialNo": enterpriseCollectSerialNo,
                  "expiredDate": expirationDate,
                  "businessLicenseKey": businessLicenseKey,
                  "businessLicenseSerialNo": authSerialNo,
                  "socialCreditCode": socialCreditCode,
                  "enterpriseName": enterpriseName,
                  "projectId": projectId,
                  "effectiveDate": effectiveDate,
                  "timestamp": 1774873469908
                } 
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            dangqianbushu += 1
            print(f'第「{dangqianbushu}」步，已上传企业营业执照信息')
            break
        else:
            retry_count += 1
            print(b1)
            print(f'「{retry_count}/{max_retries}」，重试中……')
            time.sleep(5)
        if retry_count == max_retries:          
            print('\n'+'*'*100)
            print(url)
            print(b1)
            print('*'*100+'\n')
            # msg: '提示',b1))
            sys.exit()

    # # msg: "提示", f'授信申请已提交成功，且已上传完营业执照'))
    # sys.exit()

    # 资料采集:查询节点状态及流水 
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/collect/stage/query'
    json = {"socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1774872738563}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        enterpriseCollectSerialNo = b1['body']['enterpriseCollectSerialNo']     # 资料采集流水号
        status = b1['body']['status']                                           # 资料采集节点状态
        if status == '00':
            print('当前资料采集节点为营业执照采集')
        elif status == '01':
            print('当前资料采集节点为关联人采集')
        elif status == '03':
            print('当前资料采集节点为打款验证')
        elif status == '04':
            print('当前资料采集节点为设置密码')
        elif status == '05':
            print('当前资料采集节点为资料采集完成')
        elif status == '06':
            print('当前资料采集节点为上送中台客户信息')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    # 获取受益人信息
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/query/relatedperson/beneficiary/info'
    json = {"socialCreditCode":sjqyzjh}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for beneficiaryList in b1['body']['beneficiaryList']:
            SYRname = beneficiaryList['name']
            print(f'获取到受益人「{SYRname}」')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()
    
    # 合同份数，初始值为0
    hetongnum = 0
    # 获取场景下的协议列表
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/signatrue/protocolList/query'
    json = {"screenType":"03","projectId":projectId}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        for protocolList in b1['body']['protocolList']:
            # 合同份数+1
            hetongnum += 1
            fileName = protocolList['fileName']
            filePath = protocolList['filePath']
            templateCode = protocolList['templateCode']
            print(f'已获取第「{hetongnum}」份合同{fileName}，合同文件路径{filePath}')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()    
    
    max_retries = 5  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 资料采集:查询经办人和法人信息、查询h5关联信息采集页面标识
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/query/cust/relation/person/info'
        json = {
                  "socialCreditCode": sjqyzjh,
                  "projectId": projectId
                }          
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            # 经办人信息
            address = b1['body']['agentPersonInfoVO']['address']
            certificateStatus = b1['body']['agentPersonInfoVO']['certificateStatus']
            effectiveDate = b1['body']['agentPersonInfoVO']['effectiveDate']
            expiredDate = b1['body']['agentPersonInfoVO']['expiredDate']
            idcardBackKey = b1['body']['agentPersonInfoVO']['idcardBackKey']
            idcardBackPath = b1['body']['agentPersonInfoVO']['idcardBackPath']
            idcardFrontKey = b1['body']['agentPersonInfoVO']['idcardFrontKey']
            idcardFrontPath = b1['body']['agentPersonInfoVO']['idcardFrontPath']
            idcardNo = b1['body']['agentPersonInfoVO']['idcardNo']
            issuAuthority = b1['body']['agentPersonInfoVO']['issuAuthority']
            phone = b1['body']['agentPersonInfoVO']['phone']
            userName = b1['body']['agentPersonInfoVO']['userName']
            # 法人信息
            address1 = b1['body']['legalPersonInfoVO']['address']
            certificateStatus1 = b1['body']['legalPersonInfoVO']['certificateStatus']
            effectiveDate1 = b1['body']['legalPersonInfoVO']['effectiveDate']
            expiredDate1 = b1['body']['legalPersonInfoVO']['expiredDate']
            idcardBackKey1 = b1['body']['legalPersonInfoVO']['idcardBackKey']               # 法人身份证背面，可能没有
            idcardFrontKey1 = b1['body']['legalPersonInfoVO']['idcardFrontKey']
            idcardFrontPath1 = b1['body']['legalPersonInfoVO']['idcardFrontPath']
            idcardNo1 = b1['body']['legalPersonInfoVO']['idcardNo']
            # userType1 = b1['body']['legalPersonInfoVO']['userType']                    
            userName1 = b1['body']['legalPersonInfoVO']['userName']
            phone1 = b1['body']['legalPersonInfoVO']['phone']
            break
        else:
            retry_count += 1
            print(b1)
            print(f'「{retry_count}/{max_retries}」重试中……')
            time.sleep(5)
        if retry_count == max_retries:
            print('\n'+'*'*100)
            print(url)
            print(b1)
            print('*'*100+'\n')
            # msg: '提示',b1))
            sys.exit()

    max_retries = 5  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 资料采集:上送企业相关人信息
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/upload/cust/relation/person/info'
        json = {
                  "cyType": "ZLCJ",
                  "controlWithlegalPersonFlag": True,
                  "agentWithlegalPersonFlag": False,
                  "enterpriseCollectSerialNo": enterpriseCollectSerialNo,           # 资料采集流水号
                  "legalPersonInfo": {                                              # 法人信息
                    "idcardBackKey": "",
                    "idcardFrontPath": idcardFrontPath1,
                    "address": address1,
                    "certificateStatus": certificateStatus1,
                    "phone": phone1,
                    "isForeignLegalPerson": True,
                    "idcardFrontKey": idcardFrontKey1,
                    "expiredDate": "9999-12-31",
                    "idcardNo": idcardNo1,
                    "userType": "100",                                              # 100：法人
                    "userName": userName1,
                    "effectiveDate": effectiveDate1
                  },
                  "cySerialNo": "",
                  "socialCreditCode": sjqyzjh,
                  "projectId": projectId,
                  "agentPersonInfo": {                                                # 经办人信息
                    "certificateIssuAuthority": issuAuthority,
                    "address": address,
                    "certificateStatus": certificateStatus,
                    "idcardBackPath": idcardBackPath,
                    "idcardNo": idcardNo,
                    "userName": userName,
                    "idcardBackKey": idcardBackKey,
                    "idcardFrontPath": idcardFrontPath,
                    "phone": phone,
                    "idcardFrontKey": idcardFrontKey,
                    "userType": "104",                                              # 104：经办人
                    "effectiveDate": effectiveDate,
                    "expirationDate": "9999-12-31"
                  },
                  "benefitWithlegalPersonFlag": True,
                  "timestamp": 1774919003965
                }
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            dangqianbushu += 1
            print(f'第「{dangqianbushu}」步，已上送企业相关人员信息')
            break
        else:
            retry_count += 1
            print(b1)
            print(f'第「{retry_count}/{max_retries}」次上送企业相关人信息，重试中……')
            time.sleep(5)                        
    if retry_count == max_retries:           
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()   

    # 资料采集:查询节点状态及流水 
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/collect/stage/query'
    json = {"socialCreditCode":sjqyzjh,"projectId":projectId,"timestamp":1774872738563}
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        enterpriseCollectSerialNo = b1['body']['enterpriseCollectSerialNo']     # 资料采集流水号
        status = b1['body']['status']                                           # 资料采集节点状态
        if status == '00':
            print('当前资料采集节点为营业执照采集')
        elif status == '01':
            print('当前资料采集节点为关联人采集')
        elif status == '03':
            print('当前资料采集节点为打款验证')
        elif status == '04':
            print('当前资料采集节点为设置密码')
        elif status == '05':
            print('当前资料采集节点为资料采集完成')
        elif status == '06':
            print('当前资料采集节点为上送中台客户信息')
    else:              
        print('\n'+'*'*100)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()
        
    # 资料采集:查询账户打款状态 # 8f92f62eb7064e5aad316a21aedc0745 bankCard
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/account/payment/status/query'
    json = {
                "enterpriseCollectSerialNo":enterpriseCollectSerialNo,                  # 资料采集流水号
                "socialCreditCode":sjqyzjh,
                "projectId":projectId                          
            }
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        pass
    else:
        print('\n'+'*'*30+'错误提示'+'*'*30)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()
    # 生成银行卡号
    bankCardNo = generate_bank_card()
    # 资料采集:账户打款
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/account/payment'
    json = {
              "linkedBankCode": "308584000013",
              "linkedBaseAcctNo": bankCardNo,
              "enterpriseCollectSerialNo": enterpriseCollectSerialNo,
              "linkedBankName": "招商银行",
              "bindAccountType": "09",
              "linkedAcctName": sjqiye,
              "socialCreditCode": sjqyzjh,
              "projectId": projectId,
              "fileList": [
                "supplychain/GC/2026-03-12/20260312174439916729629UAT票据1.png"
              ],
              "bindAccountDept": "招商银行",
              "timestamp": 1773308709879
            } 
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('已绑定银行卡，进行打款验证')  
        dangqianbushu += 1
        print(f"第「{dangqianbushu}」步，已绑定银行卡，进行打款验证")   
    else:
        print('\n'+'*'*30+'错误提示'+'*'*30)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

    max_retries = 6  # 设置最大重试次数
    retry_count = 0  # 当前重试次数
    while retry_count < max_retries:
        # 资料采集:打款验证
        url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/account/payment/verification'     
        json = {
                  "enterpriseCollectSerialNo": enterpriseCollectSerialNo,
                  "checkAmt": 1,
                  "socialCreditCode": sjqyzjh,
                  "projectId": projectId,
                  "timestamp": 1773309142854
                }   
        a1 = requests.post(url,headers=headers,json=json)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            print('打款验证成功')  
            dangqianbushu += 1
            print(f"第「{dangqianbushu}」步，打款验证成功")
            break
        else:
            retry_count += 1
            print(b1)
            print(f'等待15秒后重新打款验证，已尝试第「{retry_count}/{max_retries}」次……')
            print(f'等待15秒后重新打款验证，已尝试第「{retry_count}/{max_retries}」次……')
            time.sleep(15)
    if retry_count == max_retries:
        print('\n'+'*'*30+'错误提示'+'*'*30)
        print(f'连续{retry_count}次打款认证失败，测试终止')
        print('\n',url)
        print('请求头:',headers)
        print('入参:',json)
        print('响应:',b1,'\n')
        # msg: "警告", b1))
        sys.exit()                          

    # 资料采集:提交客户信息采集-终态
    url = wxsbank_supplychain_web+'/wxsbank-supplychain-web/enterprise/submit/cust/information'
    json = {
              "enterpriseCollectSerialNo": enterpriseCollectSerialNo,
              "socialCreditCode": sjqyzjh,
              "projectId": projectId,
              "timestamp": 1773311431180
            }     
    a1 = requests.post(url,headers=headers,json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        print('资料采集提交成功')  
        dangqianbushu += 1
        print(f"第「{dangqianbushu}」步，资料采集提交成功，造数测试流程完结\n")
        print(farentype+'*'*20+f'{ussjname}'+'*'*20)
        print(f'企业名称:{sjqiye}')
        print(f'企业证件号:{sjqyzjh}')
        print(f'法人名称:{ussjname}')
        print(f'法人证件号:{uszjh}')
        print(f'法人手机号:{phone_number}')
        print(f'经办人名称:{sjjbrname}')
        print(f'经办人证件号:{sjsfz}')
        print(f'经办人手机号:{jbrphone}')
        print('经办人免密登录地址:',mianmidenglu)
        print('法人免密登录地址:',mianmidenglu1)
        print('*'*50)
        print('*'*20+f'{ussjname}'+'*'*20)
        print(f'企业名称:{sjqiye}')
        print(f'企业证件号:{sjqyzjh}')
        print(f'法人名称:{ussjname}')
        print(f'法人证件号:{uszjh}')
        print(f'法人手机号:{phone_number}')
        print(f'经办人名称:{sjjbrname}')
        print(f'经办人证件号:{sjsfz}')
        print(f'经办人手机号:{jbrphone}')
        print('*'*50)
        # msg: '提示',f'{sjqiye}\n{farentype}\n数据已准备完毕'))
    else:
        print('\n'+'*'*30+'错误提示'+'*'*30)
        print(url)
        print(b1)
        print('*'*100+'\n')
        # msg: '提示',b1))
        sys.exit()

print("\n完成")
