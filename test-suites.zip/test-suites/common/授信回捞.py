# -*- coding: utf-8 -*-
import sys, re, time, requests, json

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""
try: SUBMITTER_TYPE = submitter_type
except NameError: SUBMITTER_TYPE = "02"

if not CERT_NO:
    print("请先点击查询客户信息后再运行")
    sys.exit()

from utils.environment import get_environment
from utils.cmp_config import get_cmp_token
env_config = get_environment(ENV)
if env_config is None:
    env_config = get_environment("SIT")
wxsbank_supplychain_cmp = getattr(env_config, "wxsbank_supplychain_cmp", "")
cmp_login_url = getattr(env_config, "cmp_login_url", "")

socialCreditCode = CERT_NO
projectId = PROJECT_ID or ""
try: qian = int(AMOUNT) if AMOUNT else 400000000
except ValueError: qian = 400000000

parts = MULTI_FUNC.split(",") if MULTI_FUNC else []
applyType = parts[0] if len(parts) > 0 and parts[0] in ("01","02") else "02"
managerId = int(parts[1]) if len(parts) > 1 else (183 if ENV=="SIT" else (116 if ENV=="UAT" else 183))

submitterLabel = "客户经理" if SUBMITTER_TYPE == "02" else "客户自主"
print(f"发起方式:{submitterLabel} 环境:{ENV} 证件号:{socialCreditCode} 金额:{qian}")
print("="*60)
print("[1] 获取CMP token...")
token = get_cmp_token(cmp_login_url)
headers = {"token": token}

if applyType == "02":
    print("[2] 大数据推送企业...")
    ent_url = "http://10.100.15.124:8089/credit-analysis/api/calculationEntIndex"
    ent_data = {"entReportVdo": {"entMessageHeaderInfoVdo": {"messageHeaderUnitVdo": {"enquireRequestSgmtVdo": {"crenqdInsId": "test", "pbcEnqrRscd": "02"}, "exchangeRateSgmtVdo": {"cnrtExrt": "6.38", "exrtVldDt": "2022-01"}, "identifierSgmtVdo": {"entIDVdoList": [{"entpIdntIdrNo": socialCreditCode, "entpIdntIdrTp": "20"}], "entnm": "test_enterprise", "entpIdntIdrNum": "5"}, "objectionPromptSgmtVdo": {}, "reportIdentifierSgmtVdo": {"idvCrRptFileId": "2022012810560048162071", "msgrpGenTm": "2099-03-22T10:56:00"}}}, "msgIdNo": "20220209MLyWAr511"}}
    r = requests.post(ent_url, json=ent_data, timeout=15)
    print(f"OK {r.json()}")

    print("  大数据推送个人...")
    ind_url = "http://10.100.15.124:8089/credit-analysis/api/calculationIndex"
    ind_data = {"indReportVdo": {"messageHeaderVdo": {"antiFrdAlrtInfVdo": {}, "enqInfoVdo": {"crEnqdInsID": "test", "crEnqdPplNm": "test", "crRptEnqdPsnCrdtNo": "default", "pbcEnqrRsCd": "01", "pbcTNGnCrPtsTpCd": "10"}, "msgidInfoVdo": {"idvCrRptFileID": "2019022117552322482916", "msgRpGenTm": "2099-03-22T10:56:00"}, "objectInfoVdo": {"crObjtnNum": "0"}, "othrIdntVdo": {}}}, "msgIdNo": "qianweiming2"}
    r = requests.post(ind_url, json=ind_data, timeout=15)
    print(f"OK {r.json()}")

print("[3] 提交申请...")
url = f"{wxsbank_supplychain_cmp}/wxsbank-supplychain-cmp/manage/exhibition/app/submit/entry/apply"
ts = int(time.time()*1000000)
data = {"applyType":applyType,"submitterType":SUBMITTER_TYPE,"partnerPlatformApplyQuota":qian,"applyDetail":"ElectronApp","fileInfo":[{"attachmentType":"JDB001","fileName":"a.jpg","fileKey":"supplychain/order/2023-10-11/20231011092658184631635.jpg"},{"attachmentType":"JDB001","fileName":"b.jpg","fileKey":"supplychain/order/2023-10-11/20231011092658184631635.jpg"}],"managerId":managerId,"submitterName":"ElectronApp","taskApplyNo":f"aaa{ts}","businessType":"01","custName":"test_enterprise","projectId":projectId,"socialCreditCode":socialCreditCode}
r = requests.post(url, headers=headers, json=data, timeout=15)
res = r.json()
if res.get("respCode") == "10000" or res.get("respCode") == 10000:
    print(f"OK 提交成功!")
else:
    print(f"FAIL {res}")
print("\n完成")
