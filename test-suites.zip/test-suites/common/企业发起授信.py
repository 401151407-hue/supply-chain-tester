# -*- coding: utf-8 -*-
"""企业发起授信 - 完整流程（从供应链测试小助手 CreditApply 搬运）"""
import sys, os, re, time, random, requests

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
# 以下变量由 Electron App 在执行前注入为 Python 全局变量
AMOUNT = amount or 300000000                           # 授信金额（分），未输入则默认300万
PARTNER_PLATFORM_ID = platform_id or multi_func     # 平台ID，优先用查询结果，回退到多功能参数
# PROJECT_NAME = project_name                         # 项目名称，来自查询项目信息

# 从统一环境配置读取各服务的接口地址
from utils.environment import get_environment
env_config = get_environment(ENV)           # 根据当前环境（SIT/UAT/DEV）获取对应URL
if env_config is None:
    env_config = get_environment("SIT")     # 回退到SIT
wxsbank_supplychain_partner = env_config.wxsbank_supplychain_partner         # 联合登录等partner端接口
wxsbank_supplychain_web = getattr(env_config, "wxsbank_supplychain_web", "")  # H5前端接口（身份证、协议、人脸等）
wxsbank_scp_small_tool = getattr(env_config, "wxsbank_scp_small_tool", "")   # 小工具接口（生成客户、Apollo挡板）
wxsbank_supplychain_product_partner = getattr(env_config, "wxsbank_supplychain_product_partner", "")  # 预授信白名单接口

def generate_phone_number():
    prefix = random.choice(["130","131","132","133","134","135","136","137","138","139","145","147","149","150","151","152","153","155","156","157","158","159","165","166","170","171","172","173","174","175","176","177","178","180","181","182","183","184","185","186","187","188","189","191","198","199"])
    suffix = "".join(random.choice("0123456789") for _ in range(8))
    return prefix + suffix

def bankCard():
    prefix = random.choice(["62148502"])
    suffix = "".join(random.choice("0123456789") for _ in range(8))
    return prefix + suffix

def get_db_connection():
    """使用统一的数据库配置"""
    from utils.database import DB_CONFIG
    import mysql.connector
    config = DB_CONFIG.get(ENV)
    if config is None:
        raise ValueError(f"未知环境: {ENV}")
    return mysql.connector.connect(**config)

def export_customer(enterpriseName, socialCreditCode, name, idCode, phone, partnerPlatformId, projectName, projectId, loginlogin):
    from datetime import datetime
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = os.path.join(os.path.expanduser("~"), "Desktop", "供应链测试_导出客户")
    os.makedirs(folder, exist_ok=True)
    fn = f"{ENV}_{projectName}_{enterpriseName}_{ts}.txt"
    fp = os.path.join(folder, fn)
    with open(fp, "w", encoding="utf-8") as f:
        f.write(f"企业名称: {enterpriseName}\n企业证件: {socialCreditCode}\n法人姓名: {name}\n")
        f.write(f"法人证件: {idCode}\n法人手机: {phone}\n平台ID: {partnerPlatformId}\n")
        f.write(f"项目名: {projectName}\n项目ID: {projectId}\n免密登录: {loginlogin}\n")
    print(f"客户信息已导出到: {fp}")

def credit_apply():
    if not project_id:                                         # 未查询项目信息则拦截，避免无效调用
        print("请先点击「查询项目信息」获取项目数据")
        return
    partnerPlatformId = PARTNER_PLATFORM_ID if PARTNER_PLATFORM_ID else "default"  # 平台ID，用于联合登录等接口
    amount_str = str(AMOUNT)
    print(f"当前环境: {ENV}")
    print(f"项目ID: {projectId}")
    print(f"证件号: {CERT_NO or '未输入'}")
    print(f"授信金额: {amount_str}")
    print(f"partnerPlatformId: {partnerPlatformId}")
    print("=" * 60)
    try: cishu = int(amount_str) if amount_str else 1
    except ValueError: cishu = 1
    xunhuancishu = 0
    for _ in range(cishu):
        dangqianbushu = 0
        print(f"\n>>> 第 {xunhuancishu+1}/{cishu} 次 <<<")
        try: qian = int(amount_str) if amount_str else 300000000
        except ValueError: qian = 300000000; print("默认授信金额300万")
        print(f"授信金额: {qian}")
        phone = generate_phone_number()
        print(f"生成手机号: {phone}")
        # 1. 联合登录
        max_retries = 5; retry_count = 0
        while retry_count < max_retries:
            url = f"{wxsbank_supplychain_partner}/wxsbank-supplychain-partner/user/federated/login"
            j = {"partnerPlatformId":partnerPlatformId,"phone":phone,"returnUrl":"11111","urlChannelType":"02","projectId":projectId}
            a1 = requests.post(url=url,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000):
                loginlogin = b1['body']['loginPath']
                print(f"免密登录地址: {loginlogin}")
                dangqianbushu += 1; print(f"[{dangqianbushu}] 联合登录: {url}")
                token = re.search(r'token=([^&]+)', loginlogin).group(1)
                print(f"提取token: {token}")
                break
            else: retry_count += 1; print(f"[{retry_count}/{max_retries}] 联合登录失败: {b1}")
        if retry_count == max_retries: print("联合登录失败"); return
        headers = {"token":token}
        # 2. 小工具生成客户
        retry_count = 0
        while retry_count < max_retries:
            url = f"{wxsbank_scp_small_tool}/wxsbank-scp-small-tool/generater/query/idcardAndBusinessLicense"
            a1 = requests.post(url=url,json={"count":1}); b1 = a1.json()
            if b1['respCode'] == str(10000):
                enterpriseName = b1['body'][0]['enterpriseName']
                socialCreditCode_val = b1['body'][0]['socialCreditCode']
                idcardFrontKey = b1['body'][0]['idcardFrontKey']
                idcardBackKey = b1['body'][0]['idcardBackKey']
                businessLicenseKey = b1['body'][0]['businessLicenseKey']
                name = b1['body'][0]['name']; idCode = b1['body'][0]['idCode']
                qwe = get_db_connection(); m11 = qwe.cursor()
                m11.execute("SELECT enterprise_name FROM supply_chain_wallet.scp_enterprise_cust_info WHERE enterprise_name = %s LIMIT 1",(enterpriseName,))
                if not m11.fetchall():
                    print(f"已生成客户: {enterpriseName}")
                    print(f"企业证件号: {socialCreditCode_val}")
                    print(f"法人姓名: {name}"); print(f"法人证件号: {idCode}")
                    dangqianbushu += 1; print(f"[{dangqianbushu}] 已生成客户「{enterpriseName}」")
                    m11.close(); qwe.close(); break
                else: retry_count += 1; print(f"数据库已有重名客户，重试...")
                m11.close(); qwe.close()
            else: retry_count += 1
        if retry_count == max_retries: print("生成客户失败"); return
        # 3. Apollo 挡板
        url = f"{wxsbank_scp_small_tool}/wxsbank-scp-small-tool/auto/deploy/meterSphere/config/saveOrUpdate"
        requests.post(url=url,json={"appid":"wxsbank-supplychain-web","namespace":"application","key":"enterprise.certification.baffle","value":{enterpriseName:socialCreditCode_val+'|'+name}})
        dangqianbushu += 1; print(f"[{dangqianbushu}] Apollo挡板已插入")
        # 4. mock天眼查
        url = f"{wxsbank_scp_small_tool}/wxsbank-scp-small-tool/mock/tian/yan/info/submit"
        j = {"regStatus":"存续","regCapital":42000000,"city":"南通市","categoryBig":"黑色金属冶炼和压延加工业","industry":"制造业","staffNum":3,"bondName":"","socialCreditCode":socialCreditCode_val,"operateStartDate":"2011-05-02","legalPersonName":name,"legalPersonType":1,"regNumber":socialCreditCode_val,"province":"","fromTime":"1999-01-01","actualCapitalCurrency":"欧元","alias":"伟达","companyOrgType":"其他股份有限公司（上市）","orgNumber":"MA6PFCNP6","enterpriseName":enterpriseName,"toTime":"9999-01-01","actualCapital":1000000,"categoryMiddle":"钢压延加工","regInstitute":"无锡市市场监督管理局","businessScope":"1货运代理...","taxNumber":socialCreditCode_val,"regLocation":"江苏省无锡市锡山区东翔路5781号","establishDate":"1970-06-11","regCapitalCurrency":"人民币","enterpriseType":"01","categorySmall":"钢压延加工","tags":"","approvedDate":"1970-06-11","district":"如东县","bondType":"","operateEndDate":"2222-05-08","category":"制造业","isMicroEnt":0}
        a1 = requests.post(url=url,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] mock天眼查已提交")
        else: print(f"mock天眼查失败: {b1}"); return
        # 5. 预授信白名单
        url = f"{wxsbank_supplychain_product_partner}/wxsbank-supplychain-product-partner/grant/credit/pre/submit"
        j = {"partnerPlatformId":partnerPlatformId,"projectId":projectId,"enterpriseName":enterpriseName,"socialCreditCode":socialCreditCode_val,"depositQuota":600000000,"applyQuota":qian,"custBusinessType":"01","enterpriseContact":name,"enterpriseContactPhone":phone,"assignRateFlag":0}
        a1 = requests.post(url=url,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 预授信白名单提交成功")
        else: print(f"预授信白名单失败: {b1}"); return
        # 6. 身份证正面识别
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/user/idcard/front/identify"
        j = {"idcardFrontKey":idcardFrontKey,"projectId":projectId,"timestamp":1773043936048}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            idcardNo = b1['body']['idcardNo']; userName = b1['body']['userName']
            detailedAddress = b1['body']['detailedAddress']; idcardFrontOcrSerialNo = b1['body']['idcardFrontOcrSerialNo']
            dangqianbushu += 1; print(f"[{dangqianbushu}] 身份证正面识别成功")
        else: print(f"身份证正面识别失败: {b1}"); return
        # 7. 身份证反面识别
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/user/idcard/back/identify"
        j = {"idcardBackKey":idcardBackKey,"idcardNo":idcardNo,"projectId":projectId,"timestamp":1773045327446}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            certificateIssuAuthority = b1['body']['certificateIssuAuthority']
            effectiveDate = b1['body']['effectiveDate']; expirationDate = b1['body']['expirationDate']
            idcardBackOcrSerialNo = b1['body']['idcardBackOcrSerialNo']
            dangqianbushu += 1; print(f"[{dangqianbushu}] 身份证反面识别成功")
        else: print(f"身份证反面识别失败: {b1}"); return
        # 8. 身份证上传
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/user/idcard/uploadV2"
        j = {"idcardBackKey":idcardBackKey,"idcardFrontOcrSerialNo":idcardFrontOcrSerialNo,"idcardFrontKey":idcardFrontKey,"expiredDate":expirationDate,"taxCitizen":"0","userName":userName,"idcardBackOcrSerialNo":idcardBackOcrSerialNo,"projectId":projectId,"certificatesNo":idcardNo,"effectiveDate":effectiveDate,"residenceAddress":detailedAddress,"timestamp":1773045536587}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 身份证上传成功")
        else: print(f"身份证上传失败: {b1}"); return
        # 9. 协议-人脸采集授权书预览
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocolList/query"
        j = {"screenType":"20","projectId":projectId,"timestamp":1773046636076}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            for fn_item in b1['body']['protocolList']:
                if fn_item['fileName'] == '《无锡锡商银行人脸信息采集授权书》':
                    u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/query"
                    a2 = requests.post(u2,headers=headers,json={"name":userName,"idcardNo":idcardNo,"timestamp":1773102943237}); b2 = a2.json()
                    if b2['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 已预览{b2['body']['fileName']}")
        # 10. 人脸识别
        retry_count = 0
        while retry_count < 10:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/generate/flag"
            j = {"name":userName,"idcardNo":idcardNo,"timestamp":1773046635840}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] != str(10000): retry_count += 1; continue
            flag = b1['body']['flag']; token1 = b1['body']['token']
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness"
            j = {"cyType":"SMRZ","flag":flag,"videoKey":"supplychain/CY/2026-03-10/20260310135446974700767abe1bf27c6a991382d5f7da3d7680e29.mov","token":token1,"timestamp":1773122088023}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): cySerialNo = b1['body']['cySerialNo']; dangqianbushu += 1; print(f"[{dangqianbushu}] 人脸识别成功"); break
            else: retry_count += 1; print(f"[{retry_count}/10] 人脸识别失败，重试...")
        if retry_count == 10: print("人脸识别失败"); return
        # 11. 签署人脸采集授权书
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/face/information/authorization/signatrue"
        j = {"name":userName,"idcardNo":idcardNo,"timestamp":1773122096319}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 已签署人脸采集授权书")
        else: print(f"签署失败: {b1}"); return
        # 12. 实名认证
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/user/idcard/face/identification/auth"
        j = {"cyType":"SMRZ","cySerialNo":cySerialNo,"projectId":projectId,"timestamp":1773122096366}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 实名认证完成")
        else: print(f"实名认证失败: {b1}"); return
        # 13. 企业认证-天眼查
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/query/cust/by/sky/eye"
        j = {"enterpriseName":enterpriseName,"timestamp":1773123512333}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] != str(10000) or not any(x['enterpriseName']==enterpriseName for x in b1.get('body',[])):
            print("天眼查未找到企业"); return
        # 14. 协议预览
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocolList/query"
        j = {"screenType":"04","socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773124481492}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            for p in b1['body']['protocolList']:
                tc = p.get('templateCode','')
                try:
                    if tc == 'GRXXCJ001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/information/collect/personal/query"
                        j2 = {"fileName":p['fileName'],"screenType":"04","projectId":projectId,"legalPersonName":name}
                    elif tc == 'JGSSJMSFSM':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/taxpayer/query"
                        j2 = {"fileName":p['fileName'],"screenType":"04","custName":enterpriseName,"socialCreditCode":socialCreditCode_val}
                    elif tc == 'QYXXCJ001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/information/collect/enterprise/query"
                        j2 = {"screenType":"04","custName":enterpriseName,"socialCreditCode":socialCreditCode_val}
                    elif tc == 'GRZXSQS001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/power/attorney/credit/query"
                        j2 = {"fileName":p['fileName'],"screenType":"04"}
                    elif tc == 'QYZXSQS001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/letter/author/ization/query"
                        j2 = {"screenType":"04","socialCreditCode":socialCreditCode_val,"enterpriseName":enterpriseName}
                    elif tc == 'DZZHGLXY001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/ebook/query"
                        j2 = {"screenType":"04","socialCreditCode":socialCreditCode_val,"enterpriseName":enterpriseName}
                    elif tc == 'SXYESQS001':
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/credit/business/apply/query"
                        j2 = {"screenType":"04","projectId":projectId,"socialCreditCode":socialCreditCode_val}
                    else:
                        u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/view/common/contract"
                        j2 = {"queryJson":{"partyName":enterpriseName,"enterpriseName":enterpriseName},"screenType":"04","templateCode":tc,"socialCreditCode":socialCreditCode_val,"enterpriseName":enterpriseName,"projectId":projectId,"timestamp":1773121840223}
                    a2 = requests.post(u2,headers=headers,json=j2); b2 = a2.json()
                    if b2['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 已预览{b2['body']['fileName']}")
                except: pass
        # 15. 第二次人脸识别
        retry_count = 0
        while retry_count < 10:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/generate/flag"
            j = {"name":"","idcardNo":"","timestamp":1773285652827}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] != str(10000): retry_count += 1; continue
            flag = b1['body']['flag']; token1 = b1['body']['token']
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness"
            j = {"cyType":"SMRZ","flag":flag,"videoKey":"supplychain/CY/2026-03-12/20260312112826950852967abe1bf27c6a991382d5f7da3d7680e29.mov","token":token1,"timestamp":1773286107189}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): cySerialNo = b1['body']['cySerialNo']; print(f"第二次人脸识别成功"); break
            else: retry_count += 1; print(f"[{retry_count}/10] 人脸识别失败")
        if retry_count == 10: print("第二次人脸识别失败"); return
        # 16. 企业信息认证
        retry_count = 0
        while retry_count < 5:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/info/upload"
            j = {"cyType":"SMRZ","selfProofFlag":"0","cySerialNo":cySerialNo,"userName":userName,"userRole":"100","socialCreditCode":socialCreditCode_val,"enterpriseName":enterpriseName,"projectId":projectId,"timestamp":1773286111169}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): grantCreditApplyNo = b1['body']['grantCreditApplyNo']; dangqianbushu += 1; print(f"[{dangqianbushu}] 企业认证通过, 编号={grantCreditApplyNo}"); break
            else: retry_count += 1; print(f"[{retry_count}/5] 企业认证失败")
        if retry_count == 5: print("企业认证失败"); return
        # 17. 手工材料
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/manually/upload/materials/query"
        j = {"sceneCode":"CN01","socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773286112477}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            ml = b1.get("body",{}).get("materialList",[])
            if ml:
                fixed = [{"fileKey":"supplychain/GC/2026-03-12/20260312145114685702475彭清反面.jpg","fileType":"02"}]
                assembled = [{"materialType":m.get("materialType"),"fileList":fixed} for m in ml]
                u2 = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/scene/material/staging"
                j2 = {"businessNo":grantCreditApplyNo,"sceneCode":"CN01","materialList":assembled,"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773298420898}
                a2 = requests.post(u2,headers=headers,json=j2); b2 = a2.json()
                if b2['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 手工材料上传成功")
        # 18. 提交授信
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/grant/credit/apply/submit"
        j = {"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773298421655}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 授信申请提交成功")
        else: print(f"授信提交失败: {b1}"); return
        # 19. 查询节点
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/collect/stage/query"
        j = {"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773301601719}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            enterpriseCollectSerialNo = b1['body']['enterpriseCollectSerialNo']
            sm = {'00':'营业执照采集','01':'关联人采集','02':'资料补充','03':'打款验证','04':'设置密码','05':'资料采集完成','06':'上送中台'}
            print(f"当前节点: {sm.get(b1['body']['status'],b1['body']['status'])}")
        # 20. 营业执照识别
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/license/identify"
        j = {"businessLicenseKey":businessLicenseKey,"skipDataCheck":True,"timestamp":1773301844280}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): authSerialNo = b1['body']['authSerialNo']; dangqianbushu += 1; print(f"[{dangqianbushu}] 营业执照识别成功")
        else: print(f"营业执照识别失败: {b1}"); return
        # 21. 上传营业执照
        retry_count = 0
        while retry_count < 10:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/license/upload/collect"
            j = {"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"expiredDate":expirationDate,"businessLicenseKey":businessLicenseKey,"businessLicenseSerialNo":authSerialNo,"socialCreditCode":socialCreditCode_val,"enterpriseName":enterpriseName,"projectId":projectId,"effectiveDate":effectiveDate,"timestamp":1773301944782}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 营业执照上传成功"); break
            else: retry_count += 1; print(f"[{retry_count}/10] 营业执照上传失败")
        if retry_count == 10: print("营业执照上传失败"); return
        # 22. 刷新节点
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/collect/stage/query"
        j = {"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773301601719}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): enterpriseCollectSerialNo = b1['body']['enterpriseCollectSerialNo']
        # 23. 关联人采集
        retry_count = 0
        while retry_count < 5:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/upload/cust/relation/person/info"
            j = {"cyType":"ZLCJ","controlWithlegalPersonFlag":True,"agentWithlegalPersonFlag":True,"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"legalPersonInfo":{"address":detailedAddress,"certificateStatus":"00","idcardBackPath":"https://test1.wxsbank.com.cn:9000/private-bucket/supplychain/small/cert/20260312/反.jpg","expiredDate":expirationDate,"issuAuthority":certificateIssuAuthority,"idcardNo":idcardNo,"userName":userName,"idcardBackKey":idcardBackKey,"idcardFrontPath":"https://test1.wxsbank.com.cn:9000/private-bucket/supplychain/small/cert/20260312/正.jpg","phone":phone,"idcardFrontKey":idcardFrontKey,"userType":"100","effectiveDate":effectiveDate},"cySerialNo":"","socialCreditCode":socialCreditCode_val,"projectId":projectId,"beneficiaryWay":"a","benefitWithlegalPersonFlag":True,"timestamp":1773305172454}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 关联人采集成功"); break
            else: retry_count += 1; print(f"[{retry_count}/5] 关联人采集失败")
        if retry_count == 5: print("关联人采集失败"); return
        # 24. 打款验证
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/account/payment/status/query"
        j = {"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773308012000}
        requests.post(url,headers=headers,json=j)
        bankCardNo = bankCard()
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/account/payment"
        j = {"linkedBankCode":"308584000013","linkedBaseAcctNo":bankCardNo,"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"linkedBankName":"招商银行","bindAccountType":"09","linkedAcctName":enterpriseName,"socialCreditCode":socialCreditCode_val,"projectId":projectId,"fileList":["supplychain/GC/2026-03-12/20260312174439916729629UAT票据1.png"],"bindAccountDept":"招商银行","timestamp":1773308709879}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 已绑定银行卡")
        else: print(f"绑定银行卡失败: {b1}"); return
        retry_count = 0
        while retry_count < 6:
            url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/account/payment/verification"
            j = {"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"checkAmt":1,"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773309142854}
            a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
            if b1['respCode'] == str(10000): dangqianbushu += 1; print(f"[{dangqianbushu}] 打款验证成功"); break
            else: retry_count += 1; print(f"[{retry_count}/6] 打款验证等待15秒..."); time.sleep(15)
        if retry_count == 6: print("打款验证失败"); return
        # 25. 资料采集提交
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/submit/cust/information"
        j = {"enterpriseCollectSerialNo":enterpriseCollectSerialNo,"socialCreditCode":socialCreditCode_val,"projectId":projectId,"timestamp":1773311431180}
        a1 = requests.post(url,headers=headers,json=j); b1 = a1.json()
        if b1['respCode'] == str(10000):
            dangqianbushu += 1; print(f"[{dangqianbushu}] 资料采集提交成功\n")
            print("*" * 70)
            print(f"企业名称: {enterpriseName}")
            print(f"企业证件: {socialCreditCode_val}")
            print(f"法人姓名: {name}")
            print(f"法人证件: {idCode}")
            print(f"法人手机: {phone}")
            print(f"免密登录: {loginlogin}")
            print("*" * 70)
            export_customer(enterpriseName, socialCreditCode_val, name, idCode, phone, partnerPlatformId, PROJECT_NAME or "未知项目", projectId, loginlogin)
        else: print(f"资料采集提交失败: {b1}"); return
        xunhuancishu += 1
    print(f"\n已生成 {xunhuancishu} 笔数据")
    print("=" * 60)
    print("全部完成")

if __name__ == "__main__":
    credit_apply()
