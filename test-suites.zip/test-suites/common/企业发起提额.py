# -*- coding: utf-8 -*-
"""企业发起提额 - 独立脚本"""
import sys, re, time, requests

ENV = sys.argv[1] if len(sys.argv) > 1 else "SIT"
try: PROJECT_ID = project_id
except NameError: PROJECT_ID = ""
try: CERT_NO = cert_no
except NameError: CERT_NO = ""
try: AMOUNT = amount
except NameError: AMOUNT = ""
try: MULTI_FUNC = multi_func
except NameError: MULTI_FUNC = ""

if not PROJECT_ID or not CERT_NO:
    print("请先点击「查询项目信息」和「查询客户信息」后再运行")
    sys.exit()

from utils.environment import get_environment
env_config = get_environment(ENV)
if env_config is None:
    env_config = get_environment("SIT")
wxsbank_supplychain_partner = env_config.wxsbank_supplychain_partner
wxsbank_supplychain_web = getattr(env_config, "wxsbank_supplychain_web", "")

socialCreditCode = CERT_NO
projectId = PROJECT_ID
partnerPlatformId = MULTI_FUNC if MULTI_FUNC else "default"
phone = "13800138000"

print(f"当前环境: {ENV}")
print(f"证件号: {socialCreditCode}")
print(f"项目ID: {projectId}")
print("="*60)

# Step 1: 联合登录
print("[1] 联合登录获取token...")
url = f"{wxsbank_supplychain_partner}/wxsbank-supplychain-partner/user/federated/login"
data = {"partnerPlatformId":partnerPlatformId,"phone":phone,"returnUrl":"11111","urlChannelType":"02","projectId":projectId}
r = requests.post(url=url, json=data, timeout=15)
res = r.json()
if res.get("respCode") != "10000":
    print(f"FAIL {res}")
    sys.exit()
m = re.search(r"token=([^&]+)", res["body"]["loginPath"])
token = m.group(1) if m else ""
print(f"OK token={token}")
headers = {"token": token}

# Step 2: 人脸识别
print("[2] 人脸识别中...")
max_retries = 10
for retry in range(max_retries):
    print(f"  尝试 {retry+1}/{max_retries}")
    # 获取随机数
    url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/generate/flag"
    data = {"name":"","idcardNo":"","timestamp":1724392792525}
    r = requests.post(url, headers=headers, json=data, timeout=15)
    res = r.json()
    if res.get("respCode") != "10000":
        print(f"FAIL {res}")
        sys.exit()
    flag = res["body"]["flag"]
    token1 = res["body"]["token"]
    print(f"  flag={flag}")

    # 查询进件方式
    url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/query/assistance/entry/flag"
    data = {"socialCreditCode":socialCreditCode,"projectId":projectId}
    r = requests.post(url, headers=headers, json=data, timeout=15)
    res = r.json()
    if res.get("respCode") != "10000":
        print(f"FAIL {res}")
        sys.exit()
    flag2 = res["body"]["borrowerAssistanceEntryFlag"]

    # 执行人脸识别
    if flag2 == 1:
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness/with/assistance/entry"
        data = {"cyType":"EDTG","flag":flag,"videoKey":"supplychain/CY/2026-03-31/202603311549477177658131774943387336.webm","socialCreditCode":socialCreditCode,"projectId":projectId,"token":token1,"timestamp":1774943388228}
    else:
        url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/cyIdentify/video/liveness"
        data = {"cyType":"EDTG","flag":flag,"videoKey":"supplychain/CY/2024-08-23/20240823140023282815090560.mp4","token":token1,"timestamp":1724392797998}
    r = requests.post(url, headers=headers, json=data, timeout=15)
    res = r.json()
    if res.get("respCode") == "10000":
        cySerialNo = res["body"]["cySerialNo"]
        print(f"OK cySerialNo={cySerialNo}")
        break
    elif res.get("respCode") == "AC_0069":
        print(f"FAIL {res}")
        sys.exit()
    else:
        print(f"  重试: {res}")
else:
    print(f"FAIL 连续{max_retries}次失败")
    sys.exit()

# Step 3: 提交提额申请
print("[3] 提交提额申请...")
url = f"{wxsbank_supplychain_web}/wxsbank-supplychain-web/quota/increase/apply/submit"
data = {"cyType":"EDTG","cySerialNo":cySerialNo,"socialCreditCode":socialCreditCode,"projectId":projectId}
r = requests.post(url, headers=headers, json=data, timeout=15)
res = r.json()
if res.get("respCode") == "10000":
    print("OK 提额申请提交成功!")
else:
    print(f"FAIL {res}")
    sys.exit()

print("\n" + "="*60)
print("提额流程完成")