from utils.environment import get_environment

env = get_environment(current_env)


# ==============================
#  可配置项（统一在这里修改）
# ==============================
a = 1#测试变量名，变量的值
b = 2
c = 3
d = 3

# ==============================
#  可配置项结束（统一在这里修改）
# ==============================
print(a+b+c)
print(env.wxsbank_scp_liquidity_partner)  # http://10.100.17.55:8012