"""
每秒输出一次，持续30秒
"""
import time

def main():
    total = 30
    print(f"开始计时，共 {total} 秒...")
    print("-" * 30)

    for i in range(1, total + 1):
        timestamp = time.strftime("%H:%M:%S", time.localtime())
        print(f"[{timestamp}] 第 {i:02d}/{total} 秒")
        if i < total:
            time.sleep(1)

    print("-" * 30)
    print("完成！")

if __name__ == "__main__":
    main()
