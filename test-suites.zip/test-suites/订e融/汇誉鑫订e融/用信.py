
"""
汇誉鑫 - 订e融 - 用信
====================
一键完成订e融用信业务流程的自动化测试
"""

import os
import sys
import requests
import time

current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import get_environment

current_env = 'SIT'
timestamp = int(time.time() * 1000000)
partnerOrderNo = f"LCLHYX{timestamp}"

# 环境配置
env = get_environment(current_env)
if env is None:
    print('\n\n\n' + '*' * 50 + '异常信息' + '*' * 50)
    print('环境选择错误')
    print('*' * 50 + 'END' + '*' * 50)
    sys.exit()

# 项目信息（随环境不同而变化）
if current_env == 'SIT':
    projectId = 'scp0009511863'
    partnerPlatformId = 'scp0009'
elif current_env == 'UAT':
    projectId = 'scp0015131989'
    partnerPlatformId = 'scp0015'

projectName = '汇誉鑫订e融'
partnerPlatformName = '汇誉鑫'


url = env.wxsbank_scp_liquidity_partner+'/wxsbank-scp-liquidity-partner/order/der/std/submit'
json = {
            "orderType": "04",  # 订单类型 03：定金订单，04：尾款订单,05-税金订单
            "partnerOrderNo": partnerOrderNo,    # 合作方订单号
            "allFinalOrderSubmitFlag": "2",
            "partnerPlatformId": "scp0026",
            "firstPayeeInfo": {
                "payeeName": "魏金娣科技",
                "payeeAccount": "19201010000249017"
            },
            "payerPhoneNo": "13193445075",
            "productInfoList": [
                {
                "goodsMeasurementOne": 100000,
                "goodsMeasurementOneUnit": "t",
                "goodsName": "全自动猪头肉",
                "goodsPrice": 100,
                "levelOneName": "全自动猪头肉一级",
                "levelThreeName": "全自动猪头肉三级",
                "levelTwoName": "全自动猪头肉二级"
                }
            ],
            "socialCreditCode": "8J387419XRCF8MB6UX",
            "orderModel": "ADVANCE_DEPOSIT_FINAL_MERGE",
            "balancePaymentAmount": 200000,
            "creditPaymentAmount": 800000,
            "orderAmount": 1000000,
            "finalPayeeList": [
                {
                "payeeName": "黄小花科技公司",
                "payeeBankName": "中国建设银行股份有限公司林口支行",
                "collectedAmount": 1000000,
                "payeeBankCode": "105275562866",
                "postscript": "",
                "payeeAccount": "12201010000000638"
                }
            ],
            "files": [
                {
                "attachmentType": "0014",
                "filesPath": [
                    {
                    "contractNo": "CG01HT100020250310103832396",
                    "contractSignDate": "2025-03-10",
                    "fileKey": "/app/share/dmzsftp/scp1/dmzsftp/hongguan/history1.xlsx",
                    "contractName": "采购合同",
                    "fileType": "02"
                    }
                ]
                },
                {
                "attachmentType": "0021",
                "filesPath": [
                    {
                    "contractNo": "01HT100020250310103832396",
                    "contractSignDate": "2025-03-10",
                    "fileKey": "/app/share/dmzsftp/scp1/dmzsftp/hongguan/history1.xlsx",
                    "contractName": "购销合同",
                    "fileType": "01"
                    },
                    {
                    "contractNo": "01HT100020250310103832396",
                    "contractSignDate": "2025-03-10",
                    "fileKey": "/app/share/dmzsftp/scp1/dmzsftp/hongguan/history1.xlsx",
                    "contractName": "购销合同",
                    "fileType": "02"
                    }
                ]
                },
                {
                "attachmentType": "0024",
                "filesPath": [
                    {
                    "contractSignDate": "2025-03-10",
                    "fileKey": "/app/share/dmzsftp/scp1/dmzsftp/hongguan/history1.xlsx",
                    "contractName": "货权转移单",
                    "fileType": "02"
                    }
                ]
                }
            ],
            "projectId": "scp0026101810"
        }
print(json)