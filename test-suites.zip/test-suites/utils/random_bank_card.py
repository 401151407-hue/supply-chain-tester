import random
# 生成随机银行卡号
def generate_bank_card(bin_prefix: str = "622588", length: int = 16) -> str:
    """
    生成符合LUHN校验的测试银行卡号

    Args:
        bin_prefix: 银行卡BIN号前缀，默认622588(招商银行信用卡测试前缀)
        length: 银行卡号总长度，默认16位

    Returns:
        符合LUHN校验的完整银行卡号字符串

    Raises:
        ValueError: BIN前缀长度 >= 卡号总长度时抛出
    """
    if len(bin_prefix) >= length:
        raise ValueError(f"BIN前缀长度({len(bin_prefix)})必须小于卡号总长度({length})")    

    # 生成BIN前缀与校验位之间的随机数字
    remaining_len = length - len(bin_prefix) - 1
    middle_digits = "".join(str(random.randint(0, 9)) for _ in range(remaining_len))
    partial_card = bin_prefix + middle_digits

    # 计算LUHN校验位
    total = 0
    reverse_digits = partial_card[::-1]
    for i, char in enumerate(reverse_digits):
        digit = int(char)
        if i % 2 == 0:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    check_digit = (10 - total % 10) % 10

    return partial_card + str(check_digit)