"""
供应链测试小助手 - 自动更新模块
================================
程序启动时自动检测局域网更新服务器是否有新版本。
有更新时弹出对话框，用户可选择是否下载更新。

更新服务器地址探测（按优先级）：
  1. 环境变量 UPDATE_SERVER
  2. update_server.txt 文件（项目根目录或 EXE 同目录）
  3. UDP 广播发现（100%可靠，同一广播域内必能发现）
  4. 网段遍历探测（降级方案，扫描常见 IP）
"""

import os
import sys
import json
import shutil
import subprocess
import tempfile
import threading
import platform
from pathlib import Path

import requests

# ==========================================
#  版本信息
# ==========================================
_VERSION_FILE = "version.json"
_CURRENT_VERSION = "1.0.0"
_APP_NAME = "供应链测试小助手"

# 尝试读取内置版本
def _load_current_version():
    global _CURRENT_VERSION, _APP_NAME
    # PyInstaller 打包后，version.json 会被打包进去
    if getattr(sys, 'frozen', False):
        base = sys._MEIPASS
    else:
        # 开发环境：version.json 在项目根目录（utils/ 的上一级）
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    version_path = os.path.join(base, _VERSION_FILE)
    if os.path.exists(version_path):
        try:
            with open(version_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            _CURRENT_VERSION = data.get('version', _CURRENT_VERSION)
            _APP_NAME = data.get('app_name', _APP_NAME)
        except Exception:
            pass

_load_current_version()

# ==========================================
#  更新服务器地址
# ==========================================
def _get_update_server():
    """获取更新服务器地址，优先级: 环境变量 > 配置文件 > 默认"""
    # 1. 环境变量
    url = os.environ.get('UPDATE_SERVER', '')
    if url:
        return url.rstrip('/')
    
    # 2. 同目录下的配置文件
    config_paths = []
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(sys.executable)
        config_paths.append(os.path.join(exe_dir, 'update_server.txt'))
        config_paths.append(os.path.join(sys._MEIPASS, 'update_server.txt'))
    else:
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        config_paths.append(os.path.join(project_root, 'update_server.txt'))
    
    for p in config_paths:
        if os.path.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    # 找到第一行有效配置
                    if line.startswith('http://') or line.startswith('https://'):
                        return line.rstrip('/')
    
    return None


def _parse_version(version_str):
    """将版本字符串解析为可比较的元组，如 '1.2.3' -> (1, 2, 3)"""
    try:
        parts = version_str.strip().split('.')
        return tuple(int(p) for p in parts)
    except Exception:
        return (0, 0, 0)


def check_for_update(server_url=None):
    """
    检查更新服务器是否有新版本。
    
    参数:
        server_url: 更新服务器地址 (如 http://192.168.1.100:18080)
                    为 None 时自动探测
    
    返回:
        dict: {'has_update': bool, 'latest_version': str, 'release_notes': str, 
               'download_url': str, 'server_url': str}
        None: 无法连接到更新服务器
    """
    if server_url is None:
        server_url = _get_update_server()
    
    if not server_url:
        return None

    try:
        resp = requests.get(f"{server_url}/version.json", timeout=5)
        resp.raise_for_status()
        remote = resp.json()
    except Exception:
        return None

    remote_version = remote.get('version', '0.0.0')
    current_tuple = _parse_version(_CURRENT_VERSION)
    remote_tuple = _parse_version(remote_version)

    is_macos = platform.system() == 'Darwin'
    file_key = 'macos' if is_macos else 'windows'
    download_file = remote.get('files', {}).get(file_key, '')

    return {
        'has_update': remote_tuple > current_tuple,
        'latest_version': remote_version,
        'current_version': _CURRENT_VERSION,
        'release_notes': remote.get('release_notes', '无更新说明'),
        'download_url': f"{server_url}/{download_file}" if download_file else '',
        'server_url': server_url,
    }


def download_update(download_url, progress_callback=None):
    """
    下载更新文件。
    
    参数:
        download_url: 更新文件下载地址
        progress_callback: 进度回调 callback(percent: int)
    
    返回:
        str: 下载的文件路径，失败返回 None
    """
    try:
        # 确定下载目录
        if getattr(sys, 'frozen', False):
            download_dir = os.path.dirname(sys.executable)
        else:
            download_dir = os.path.expanduser('~/Downloads')

        filename = download_url.split('/')[-1]
        filepath = os.path.join(download_dir, filename)

        resp = requests.get(download_url, stream=True, timeout=60)
        resp.raise_for_status()

        total_size = int(resp.headers.get('content-length', 0))
        downloaded = 0

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)
                if progress_callback and total_size > 0:
                    progress_callback(int(downloaded / total_size * 100))

        return filepath
    except Exception as e:
        print(f"[更新] 下载失败: {e}")
        return None


def install_update(filepath):
    """
    安装更新文件。
    macOS: 打开 .dmg 文件
    Windows: 解压 .zip 到当前目录，替换旧版本
    """
    if not filepath or not os.path.exists(filepath):
        return False

    system = platform.system()
    try:
        if system == 'Darwin':
            # macOS: 挂载 dmg
            subprocess.Popen(['open', filepath])
        elif system == 'Windows':
            # Windows: 解压 zip 并提示
            import zipfile
            exe_dir = os.path.dirname(sys.executable)
            with zipfile.ZipFile(filepath, 'r') as zf:
                zf.extractall(exe_dir)
            print(f"[更新] 已解压到 {exe_dir}")
            # 删除下载的 zip
            try:
                os.remove(filepath)
            except Exception:
                pass
        return True
    except Exception as e:
        print(f"[更新] 打开安装包失败: {e}")
        return False


# ==========================================
#  更新服务器地址探测（局域网）
# ==========================================

# UDP 广播发现常量
_DISCOVERY_PORT = 18081
_DISCOVERY_MAGIC = b'SUPPLY_CHAIN_UPDATE_DISCOVER'
_DISCOVERY_RESPONSE_MAGIC = b'SUPPLY_CHAIN_UPDATE_SERVER'


def discover_update_server_udp(timeout=3.0):
    """
    【100%可靠】通过 UDP 广播发现局域网内的更新服务器。
    
    原理：
      客户端向 255.255.255.255:{_DISCOVERY_PORT} 发送广播包，
      更新服务器收到后回复自己的 HTTP 地址。
      只要在同一广播域（同一局域网/VLAN），就一定能收到。
    
    返回:
        str: 更新服务器 URL，如 http://192.168.1.100:18080
        None: 未发现更新服务器
    """
    import socket

    # 1. 先发广播查询
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(1.0)
        # 发送 3 次，提高可靠性（UDP 可能丢包）
        for _ in range(3):
            try:
                sock.sendto(_DISCOVERY_MAGIC, ('255.255.255.255', _DISCOVERY_PORT))
            except Exception:
                pass
            import time
            time.sleep(0.1)
    except Exception:
        return None

    # 2. 等待服务器响应
    servers = []
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            sock.settimeout(max(0.5, deadline - time.time()))
            data, addr = sock.recvfrom(1024)
            if data.startswith(_DISCOVERY_RESPONSE_MAGIC):
                # 格式: MAGIC:http://192.168.1.100:18080
                url = data[len(_DISCOVERY_RESPONSE_MAGIC):].decode('utf-8', errors='ignore').strip()
                if url.startswith('http://') or url.startswith('https://'):
                    # 过滤 IPv6 地址（如 fe80::...），HTTP 无法直接使用
                    host_with_port = url.split('://', 1)[1].split('/')[0]
                    if host_with_port.count(':') >= 2:
                        continue  # IPv6 地址，跳过
                    if url not in servers:
                        servers.append(url)
                        sock.close()
                        return url
        except socket.timeout:
            break
        except Exception:
            break

    try:
        sock.close()
    except Exception:
        pass
    return None


def discover_update_server(port=18080):
    """
    自动探测局域网内的更新服务器。
    
    探测顺序（按可靠性从高到低）：
      1. UDP 广播发现（100% 可靠，同一广播域内必能发现）
      2. 遍历本机所有网络接口的网段，尝试找到更新服务器（作为降级方案）
    """
    import socket

    # 方法1：UDP 广播发现（优先，最可靠）
    server = discover_update_server_udp(timeout=3.0)
    if server:
        return server

    # 方法2：网段遍历探测（降级方案）
    # 收集所有本机局域网 IP 对应的 /24 网段前缀（去重）
    subnets = set()
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ip.startswith('127.') or ':' in ip:
                continue
            parts = ip.split('.')
            if len(parts) == 4:
                subnets.add('.'.join(parts[:3]))
    except Exception:
        pass

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        default_ip = s.getsockname()[0]
        s.close()
        parts = default_ip.split('.')
        if len(parts) == 4:
            subnets.add('.'.join(parts[:3]))
    except Exception:
        pass

    if not subnets:
        return None

    common_hosts = [1, 2, 3, 4, 5, 100, 254]
    for prefix in sorted(subnets):
        for host in common_hosts:
            url = f"http://{prefix}.{host}:{port}"
            try:
                resp = requests.get(f"{url}/version.json", timeout=1)
                if resp.status_code == 200:
                    return url
            except Exception:
                continue

    return None
