"""
环境配置模块
============
集中管理各环境（SIT / UAT）的服务地址，供各产品脚本统一调用。

使用方式
--------
>>> from utils import get_environment
>>> env = get_environment("SIT")
>>> print(env.wxsbank_scp_small_tool)
http://10.100.15.130:1111
"""

from types import SimpleNamespace

# 各环境服务地址配置
ENVIRONMENTS = {
    "DEV": {
        "wxsbank_scp_liquidity_partner":      "http://10.100.17.11:8012",
        "wxsbank_scp_small_tool":             "http://10.100.15.130:1111",
        "wxsbank_supplychain_pcl_partner":    "http://10.100.17.55:8100",        
        "wxsbank_supplychain_portal_web":     "http://10.100.22.98:8166",
        "wxsbank_supplychain_partner":        "http://10.100.17.55:8072",
        "wxsbank_supplychain_web":            "http://10.100.22.98:8071",
        "wxsbank_supplychain_product_partner": "http://10.100.17.55:8083",
        "wxsbank_supplychain_adam":           "http://10.100.22.98:8112",
        "wxsbank_supplychain_cmp":           "http://10.100.22.98:8074",
        "cmp_login_url":                     "http://10.100.14.25:8062",
        "cmp_url":                            "http://10.100.14.25:8018/#/login",
    },
    "SIT": {
        "wxsbank_scp_liquidity_partner":      "http://10.100.17.551:8012",
        "wxsbank_scp_small_tool":             "http://10.100.15.130:1111",
        "wxsbank_supplychain_pcl_partner":    "http://10.100.17.55:8100",        
        "wxsbank_supplychain_portal_web":     "http://10.100.22.98:8166",   # 门户
        "wxsbank_supplychain_partner":        "http://10.100.17.55:8072",   # 合作方门户
        "wxsbank_supplychain_web":            "http://10.100.22.98:8071",   # 供应链H5
        "wxsbank_supplychain_product_partner": "http://10.100.17.55:8083",   # 供应链产品合作方
        "wxsbank_supplychain_adam":           "http://10.100.22.98:8112",   # 供应链ADAM
        "wxsbank_supplychain_cmp":            "http://10.100.22.98:8074",
        "cmp_login_url":                      "http://10.100.14.25:8062",
        "cmp_url":                            "http://10.100.14.25:8018/#/login",   # 后管页面
    },
    "UAT": {
        "wxsbank_scp_liquidity_partner":      "http://10.100.17.32:8012",
        "wxsbank_scp_small_tool":             "http://10.100.15.131:1111",
        "wxsbank_supplychain_pcl_partner":    "http://10.100.17.32:8100",
        "wxsbank_supplychain_portal_web":     "http://10.100.15.49:8067",   # 门户
        "wxsbank_supplychain_partner":        "http://10.100.15.131:8072",   # 合作方门户
        "wxsbank_supplychain_web":            "http://10.100.15.131:8071",   # 供应链H5
        "wxsbank_supplychain_product_partner": "http://10.100.17.32:8083",   # 供应链产品合作方
        "wxsbank_supplychain_adam":           "http://10.100.15.131:8111",   # 供应链ADAM
        "wxsbank_supplychain_cmp":            "http://10.100.15.131:8074",
        "cmp_login_url":                      "http://10.100.16.15:8062",
        "cmp_url":                            "http://10.100.16.15:8015/#/login",   # 后管页面
    },
}


def get_environment(env: str) -> SimpleNamespace | None:
    """
    获取指定环境的地址配置。

    参数
    ----
    env : str
        环境名称，如 "SIT" / "UAT"

    返回
    ----
    SimpleNamespace | None
        可通过 .属性名 访问地址，如 env.wxsbank_scp_small_tool；
        若环境不存在则返回 None。
    """
    config = ENVIRONMENTS.get(env)
    if config is None:
        return None
    return SimpleNamespace(**config)
