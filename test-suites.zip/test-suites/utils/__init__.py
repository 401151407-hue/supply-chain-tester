"""
utils —— 供应链测试通用工具包
================================

提供各产品业务流程脚本中复用的公共功能，包括：

- 客户信息导出
- 随机手机号 / 银行卡号生成
- 调试用的行号输出
- 环境配置
- 数据库查询

使用示例
--------
>>> from utils import generate_phone, generate_bank_card
>>> phone = generate_phone()
>>> card  = generate_bank_card()

>>> from utils import query_db
>>> result = query_db("SELECT * FROM table LIMIT 1", env="SIT")

导出清单
--------
:export_customer_info:      导出客户信息
:generate_phone:            生成随机手机号
:generate_bank_card:        生成随机银行卡号
:print_current_line_number: 打印当前代码行号
:get_environment:           获取当前环境配置
:query_db:                  执行数据库查询
:query_customer_full_info:  根据社会信用代码查完整客户画像
"""

from .random_phone import generate_phone
from .random_bank_card import generate_bank_card
from .line_counter import print_current_line_number
from .environment import get_environment

# 重量模块（需第三方库），导入失败不影响轻量模块
try:
    from .database import query_db
except ImportError:
    query_db = None

try:
    from .customer_query import query_customer_full_info
except ImportError:
    query_customer_full_info = None

try:
    from .customer_export import export_customer_info
except ImportError:
    export_customer_info = None

__all__ = [
    "export_customer_info",
    "generate_phone",
    "generate_bank_card",
    "print_current_line_number",
    "get_environment",
    "query_db",
    "query_customer_full_info",
]