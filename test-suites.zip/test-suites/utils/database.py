"""
数据库查询模块
============
根据环境自动连接对应的数据库，执行 SQL 查询并返回结果。

使用方式
--------
>>> from utils import query_db
>>> result = query_db("SELECT * FROM table LIMIT 1", env="SIT")
"""

import mysql.connector

# 各环境数据库配置
DB_CONFIG = {
    "DEV": {
        "host": "10.100.12.187",
        "user": "zhangyang",
        "password": "123456",
        "port": "3306",
    },
    "SIT": {
        "host": "10.100.14.212",
        "user": "liaochenglu",
        "password": "Z5SIq1fy&S",
        "port": "3306",
    },
    "UAT": {
        "host": "10.100.20.225",
        "user": "liaochenglu",
        "password": "Z5SIq1fy&S",
        "port": "3306",
    },
}


def query_db(sql: str, env: str = "SIT", database: str = None, params: tuple = None):
    """
    执行 SQL 查询并返回结果。

    参数
    ----
    sql : str
        要执行的 SQL 语句
    env : str
        环境名称，"SIT" 或 "UAT"
    database : str, optional
        指定数据库名，不传则使用默认库

    返回
    ----
    list[tuple]
        查询结果列表
    """
    config = DB_CONFIG.get(env)
    if config is None:
        raise ValueError(f"未知环境: {env}")

    connect_args = dict(config)
    if database:
        connect_args["database"] = database
    conn = mysql.connector.connect(**connect_args)
    cursor = conn.cursor()
    cursor.execute(sql, params or ())
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return result

