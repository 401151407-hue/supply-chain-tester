import os
import platform
from datetime import datetime
from pathlib import Path
from typing import Optional


def export_customer_info(
    enterprise_name: str,                       # 企业名称
    social_credit_code: str,                    # 企业证件号
    name: str,                                  # 法人姓名
    id_code: str | int,                         # 法人证件号
    phone: str,                                 # 手机号
    partner_platform_id: str,                   # 平台ID
    project_name: str,                          # 项目名称
    project_id: str,                            # 项目ID
    login_url: Optional[str] = None,            # 免密登录地址
    grantCreditPath: Optional[str] = None,      # 个贷授信进件URL borrowerId
    borrowerId: Optional[str] = None,           # 借款人关联ID
    env_name: Optional[str] = None,             # 当前环境，文件名的当前环境
    os_name: Optional[str] = None,              # Mac系统还是Windows系统
    windows_base_dir: Optional[str] = None,     # Windows系统的保存路径
    mac_base_dir: Optional[str] = None,         # Mac系统的保存路径        
) -> str:
    """Export customer information to a text file and optionally append to an Excel sheet.

    Returns the path of the generated text file.
    """

    if os_name is None:
        os_name = platform.system()

    now = datetime.now()
    timestamp = now.strftime("%Y%m%d%H%M%S")
    filename = f"{env_name}_{project_name}_{enterprise_name}_{timestamp}.txt"

    if windows_base_dir is None:
        windows_base_dir = r"C:\自动化测试\测试数据\客户信息"
    if mac_base_dir is None:
        mac_base_dir = "/Users/liaochenglu/Downloads/test01"

    if os_name == "Windows":
        directory_path = os.path.join(windows_base_dir, now.strftime("%Y%m%d"))
    else:
        directory_path = os.path.join(mac_base_dir, now.strftime("%Y%m%d"))

    Path(directory_path).mkdir(parents=True, exist_ok=True)
    file_path = os.path.join(directory_path, filename)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(f"企业名称:{enterprise_name}\n")
        f.write(f"企业证件号:{social_credit_code}\n")
        f.write(f"法人姓名:{name}\n")
        f.write(f"法人证件号:{id_code}\n")
        f.write(f"手机号:{phone}\n")
        f.write(f"平台ID:{partner_platform_id}\n")
        f.write(f"项目名称:{project_name}\n")
        f.write(f"项目ID:{project_id}\n\n")
        # 如果没有借款人关联ID就不打印出来            
        if borrowerId is not None:
            f.write(f"借款人关联ID:{borrowerId}\n\n")           
        # 如果没有外网免密登录地址就不打印出来
        if login_url is not None:
            f.write(f"外网免密登陆地址:{login_url}\n\n")
        # 如果没有个贷授信进件地址就不打印出来            
        if grantCreditPath is not None:
            f.write(f"个贷授信进件URL:{grantCreditPath}\n\n")
         

    return file_path
