import inspect
# 输出当前行数
def print_current_line_number():
    """打印出当前行号"""
    # 获取当前栈帧对象
    current_frame = inspect.currentframe()
    # 获取调用者栈帧对象（因为我们想获取的是print_current_line_number的调用者的行号）
    caller_frame = current_frame.f_back
    # 获取调用者的行号
    line_no = caller_frame.f_lineno
    print(f"当前异常行号是: {line_no}")