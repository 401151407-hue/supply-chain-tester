"""
客户信息综合查询模块
====================
根据社会信用代码，串联查询企业信息、法人信息、授信信息、项目信息，
返回完整的客户画像数据。

使用方式
--------
>>> from utils import query_customer_full_info
>>> info = query_customer_full_info("W4744310C6WX18JDQ3", env="SIT")
>>> print(info["enterprise_name"])      # 企业名称
>>> print(info["project_name"])         # 项目名称
"""

from .database import query_db


def query_customer_full_info(social_credit_code: str, env: str = "SIT", database: str = None):
    """
    根据统一社会信用代码，查询完整客户信息。

    参数
    ----
    social_credit_code : str
        统一社会信用代码
    env : str
        环境名称，"SIT" 或 "UAT"
    database : str, optional
        指定数据库名

    返回
    ----
    dict | None
        包含企业、法人、授信、项目信息的字典，未找到则返回 None
    """
    # ---- 1. 查企业信息 ----
    sql = f"""
        SELECT id, cust_id, enterprise_name, social_credit_code,
               business_license_key
        FROM supply_chain_wallet.scp_enterprise_cust_info
        WHERE social_credit_code = '{social_credit_code}'
        LIMIT 1
    """
    rows = query_db(sql, env=env, database=database)
    if not rows:
        return None
    cust_row = rows[0]
    cust_id = cust_row[0]

    # ---- 2. 查法人信息 ----
    sql = f"""
        SELECT legal_person_name, idcard_no, idcard_front_key, idcard_back_key,
               register_phone, scp_cust_id
        FROM supply_chain_wallet.scp_enterprise_corporation_info
        WHERE scp_cust_id = {cust_id}
          AND status = '10'
        LIMIT 1
    """
    rows = query_db(sql, env=env, database=database)
    corp_row = rows[0] if rows else [None] * 6

    # ---- 3. 查授信申请信息，拿到 project_id ----
    sql = f"""
        SELECT project_id, apply_no, credit_amt, audit_status
        FROM supply_chain_rm.credit_apply_info
        WHERE social_credit_code = '{social_credit_code}'
        ORDER BY id DESC
        LIMIT 1
    """
    rows = query_db(sql, env=env, database=database)
    if not rows:
        print(f'未查询到社会信用代码 {social_credit_code} 的授信记录，无法获取到对应项目信息')
        credit_row = [None] * 4
    else:
        credit_row = rows[0]
    project_id = credit_row[0]

    # ---- 4. 查项目信息 ----
    project_name = None
    partner_platform_id = None
    partner_platform_name = None
    if project_id:
        sql = f"""
            SELECT project_name, partner_platform_id, partner_platform_name
            FROM supply_chain_pimp.scp_project_info
            WHERE project_id = '{project_id}'
            LIMIT 1
        """
        rows = query_db(sql, env=env, database=database)
        if rows:
            project_row = rows[0]
            project_name = project_row[0]
            partner_platform_id = project_row[1]
            partner_platform_name = project_row[2]

    return {
        # 企业信息
        "id": cust_row[0],
        "cust_id": cust_row[1],
        "enterprise_name": cust_row[2],
        "social_credit_code": cust_row[3],
        "business_license_key": cust_row[4],
        # 法人信息
        "legal_person_name": corp_row[0],
        "idcard_no": corp_row[1],
        "idcard_front_key": corp_row[2],
        "idcard_back_key": corp_row[3],
        "register_phone": corp_row[4],
        # 授信信息
        "project_id": project_id,
        "apply_no": credit_row[1],
        "credit_amt": credit_row[2],
        "audit_status": credit_row[3],
        # 项目信息
        "project_name": project_name,
        "partner_platform_id": partner_platform_id,
        "partner_platform_name": partner_platform_name,
    }
