"""
CMP（审批系统）登录配置
======================
集中管理 CMP 审批系统的登录账号密码，按操作人区分。
用信审批脚本拿到当前操作人后，调用 get_cmp_account() 获取对应账号。
CMP 地址在 utils/environment.py 的 cmp_url 中配置。

使用方式
--------
>>> from utils.cmp_config import get_cmp_account
>>> account = get_cmp_account("张三")
>>> print(account["username"])   # xs0062
>>> print(account["password"])   # Password01!
"""

# ==============================
#  可配置项（统一在这里修改）
# ==============================
# 默认登录账号（首次登录用）
DEFAULT_USERNAME = 'xs0062'          # 王泽波，首次登录账号
DEFAULT_PASSWORD = 'Password01!'     # 王泽波，首次登录密码

# 操作人 -> 审批账号 映射表（退出后再登录时根据操作人匹配）
# key: 审批流程中的操作人姓名, value: {username, password}
OPERATOR_ACCOUNTS = {
    '王泽波':        {'username': 'xs0062',      'password': 'Password01!'},
    # '李四':        {'username': 'xs0063',      'password': 'Password02!'},
    # 新增操作人按上述格式添加
}
# ==============================
#  可配置项结束（统一在这里修改）
# ==============================


def get_cmp_account(operator: str) -> dict | None:
    """
    根据操作人姓名获取对应的 CMP 审批账号密码。

    参数
    ----
    operator : str
        审批流程中获取到的操作人姓名（如 '张三'）

    返回
    ----
    dict {"username": "xs0062", "password": "Password01!"}
    未匹配到时返回 None
    """
    return OPERATOR_ACCOUNTS.get(operator)


import requests, json, base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5

def get_cmp_token(cmp_login_url: str, username: str = None, password: str = None) -> str:
    user = username or DEFAULT_USERNAME
    pwd = password or DEFAULT_PASSWORD
    def encrypt(public_key, password):
        rsa_key = RSA.import_key(public_key)
        cipher = PKCS1_v1_5.new(rsa_key)
        return base64.b64encode(cipher.encrypt(password.encode())).decode()
    r = requests.post(f"{cmp_login_url}/sso/getPublicKey", headers={"Content-Type":"application/json"}, timeout=15)
    pk = r.json()["result"]
    fk = f"-----BEGIN PUBLIC KEY-----\n{pk}\n-----END PUBLIC KEY-----"
    ep = encrypt(fk, pwd)
    r2 = requests.post(
        f"{cmp_login_url}/sso/sign/login",
        headers={"Content-Type":"application/json"},
        data=json.dumps({"password": ep, "publicKey": pk, "username": user}),
        timeout=15
    )
    token = r2.json()["result"]
    print(f"OK token={token[:20]}...")
    return token
