# 药师帮个人信e融2
# 准备授信数据
# 因为绑定的是二类户，需要走真实的验证码，卡在这里暂时走不通，只能是生成相关数据

import json
import os
import requests
import sys
from datetime import datetime 		# 打印出当前时间用的
import re 							# 正则
current_dir = os.path.dirname(__file__)			# 取当前py文件所在的目录
parent_dir = os.path.dirname(os.path.dirname(current_dir))		# 取当前所在文件夹的父目录
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import generate_phone				# 生成随机手机号
from utils import generate_bank_card			# 生成随机银行卡号
from utils import print_current_line_number		# 输出当前行数
from utils import export_customer_info			# 导出客户信息
from utils import get_environment				# 获取环境地址配置

# 给变量赋予初始值，均为None
grantCreditPath = None		# 个贷授信进件URL
login_url = None			# 免密联合登录URL
borrowerId = None			# 借款人关联ID
current_env = 'SIT'			# 当前环境，默认为SIT

# 变量维护
env = get_environment(current_env)      # 从环境配置模块获取服务地址
if env is None:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print('环境选择错误')
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 项目信息（随环境不同而变化）
# if current_env == 'SIT':
# 	projectId = 'scp0009511863'
# 	partnerPlatformId = 'scp0009'
# elif current_env == 'UAT':
# 	projectId = 'scp0015131989'
# 	partnerPlatformId = 'scp0015'

# projectName = '药师帮个人信e融2'
# partnerPlatformName = '药师帮'

# ==============================
#  可配置项（统一在这里修改）
# ==============================
projectId = ''				# 项目ID
projectName = ''			# 项目名称
partnerPlatformId = ''		# 平台ID
partnerPlatformName = ''	# 平台名称

# ==============================
#  可配置项结束（统一在这里修改）
# ==============================   

# 当前步骤数，默认从0开始，每执行一个步骤就+1
StepNum = 0

# 调小工具生成客户信息
url = env.wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/generater/query/idcardAndBusinessLicense'
json = {"count":1}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	enterpriseName = b1['body'][0]['enterpriseName']				# 企业名称
	socialCreditCode = b1['body'][0]['socialCreditCode']			# 企业证件号
	name = b1['body'][0]['name']									# 法人名称
	idCode = b1['body'][0]['idCode']								# 法人证件号
	idcardFrontKey = b1['body'][0]['idcardFrontKey']				# 法人身份证正面照片路径
	idcardBackKey = b1['body'][0]['idcardBackKey']					# 法人身份证反面照片路径
	businessLicenseKey = b1['body'][0]['businessLicenseKey']		# 企业营业执照照片路径
	BankCardNo = generate_bank_card()								# 生成随机银行卡号
	phone = generate_phone()										# 生成随机手机号
	print('*'*50+f'{enterpriseName}'+'*'*50)
	print(f'企业名称:{enterpriseName}')
	print(f'企业证件号:{socialCreditCode}')
	print(f'法人名称:{name}')
	print(f'法人证件号:{idCode}')
	print(f'银行卡号:{BankCardNo}')
	print(f'手机号:{phone}')
	print('*'*50+'客户信息准备成功'+'*'*50+'\n')		
	StepNum += 1
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已通过小工具生成客户信息')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 天眼查mock数据提交
url = env.wxsbank_scp_small_tool+'/wxsbank-scp-small-tool/mock/tian/yan/info/submit'
json = {
		  "socialCreditCode": socialCreditCode,
		  "legalPersonName": name,
		  "enterpriseType": "01",
		  "toTime": "9999-01-01",
		  "fromTime": "1999-01-01",
		  "socialOrgType": None,
		  "actualCapital": 1000000,
		  "actualCapitalCurrency": "欧元",
		  "alias": "伟达",
		  "approvedDate": "1970-06-11",
		  "bondName": "",
		  "bondType": "",
		  "businessScope": "1货运代理、国际货物运输代理；普通货物道路运输、冷藏车道路运输、集装箱道路运输；货运配载；搬运装卸；普通货物仓储服务（ 不含危险化学品）； 物流方案的设计与策划； 汽车租赁； 汽车修理与维护； 建筑工程劳务与分包； 商务信息咨询；承办会议及商品展览展示活动； 汽车、 仪器仪表、 五金交电、 汽车、 摩托车配件、 其他机械设备及电子产品、 日用百货的销售。（ 依法须经批准的项目， 经相关部门批准后方可开展经营活动） ",
		  "category": "制造业",
		  "categoryBig": "黑色金属冶炼和压延加工业",
		  "categoryMiddle": "钢压延加工",
		  "categorySmall": "钢压延加工",
		  "city": "南通市",
		  "companyOrgType": "其他股份有限公司（上市）",
		  "district": "如东县",
		  "enterpriseName": enterpriseName,
		  "establishDate": "1970-06-11",
		  "industry": "制造业",
		  "isMicroEnt": 0,
		  "legalPersonType": 1,
		  "operateEndDate": "2222-05-08",
		  "operateStartDate": "2011-05-02",
		  "orgNumber": "MA6PFCNP6",
		  "province": "",
		  "regCapital": 42000000,
		  "regCapitalCurrency": "人民币",
		  "regInstitute": "无锡市市场监督管理局",
		  "regLocation": "江苏省无锡市锡山区东翔路5781号",
		  "regNumber": "64477939RX963XEN45",
		  "regStatus": "存续",
		  "staffNum": 3,
		  "tags": "",
		  "taxNumber": "8H149946F0J9BQQJ1E"
		}	
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已提交天眼查mock数据')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 提交预授信接口
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-partner/grant/credit/pre/apply/submit'
json = {
		  "applyQuota": 10000000,					# 申请额度
		  "depositQuota": 500000000,				# 担保额度
		  "enterpriseName": enterpriseName,
		  "socialCreditCode": socialCreditCode,
		  "idCardNo": None,
		  "projectId": projectId,
		  "screenData": {
		    "name": {
		      "remark": "123"
		    }
		  }
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	borrowerId = b1['body']['borrowerId']	
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已提交预授信接口，已提取借款人关联ID:{borrowerId}')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 获取授信进件URL
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-partner/grant/credit/entry/path'
json = {
		  "projectId": projectId,
		  "returnUrl": "http://www.baidu.com",
		  "urlChannelType": "02",
		  "borrowerId": borrowerId
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	grantCreditPath = b1['body']['grantCreditPath']
	# 正则提取返回URL里面的applyNo
	match = re.search(r'applyNo=([a-f0-9]+)', grantCreditPath)
	applyNo = match.group(1)	
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取授信进件URL:{grantCreditPath}')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 导出客户信息
export_customer_info(enterprise_name=enterpriseName,
					social_credit_code=socialCreditCode,
					name=name,
					id_code=idCode,
					phone=phone,
					partner_platform_id=partnerPlatformId,
					project_name=projectName,
					project_id=projectId,
					env_name=current_env,
					borrowerId=borrowerId,
					grantCreditPath=grantCreditPath,
					login_url=login_url
					)	

# 下面开始去页面上操作	

# 身份证正面识别
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/no/token/user/idCard/front/identify/ocr'
json = {
		  "idCardFrontKey": idcardFrontKey,
		  "applyNo": applyNo,
		  "processType": "02",
		  "projectId": projectId,
		  "timestamp": 1779417202283
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	address = b1['body']['address']										# 江苏省南京市建邺区西环郊区
	area = b1['body']['area']											# 锡山区
	city = b1['body']['city']											# 无锡市
	detailedAddress = b1['body']['detailedAddress']						# 江苏省南京市建邺区西环郊区
	idCardFrontOcrSerialNo = b1['body']['idCardFrontOcrSerialNo']		# IDENTIFY10057601220260522102550
	idCardNo = b1['body']['idCardNo']									# 320105199309202974
	province = b1['body']['province']									# 江苏省
	userBirth = b1['body']['userBirth']									# 1993-09-20
	userName = b1['body']['userName']									# 薛小云		
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，身份证正面已识别成功')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 身份证反面识别
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/no/token/user/idCard/back/identify/ocr'
json = {
		  "idCardNo": idCardNo,
		  "applyNo": applyNo,
		  "idCardBackKey": idcardBackKey,
		  "processType": "02",
		  "projectId": projectId,
		  "timestamp": 1779417958137
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	certificateIssuAuthority = b1['body']['certificateIssuAuthority']	# 江苏省南京市建邺区
	effectiveDate = b1['body']['effectiveDate']							# 2016-02-19
	expirationDate = b1['body']['expirationDate']						# 9999-12-31	
	idCardBackOcrSerialNo = b1['body']['idCardBackOcrSerialNo']			# IDENTIFY10057601320260522103826	
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，身份证反面已识别成功')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 营业执照识别
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/no/token/business/license/identify/ocr'
json = {
		  "businessLicenseKey": businessLicenseKey,
		  "applyNo": applyNo,
		  "processType": "02",
		  "timestamp": 1779418181673
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	authSerialNo = b1['body']['authSerialNo']							# 20260522104210302002887000150492
	enterpriseName = b1['body']['enterpriseName']						# 薛小云科技公司
	expirationDate = b1['body']['expirationDate']						# 9999-12-31
	socialCreditCode = b1['body']['socialCreditCode']					# FM987448BEWFC3TJ4W	
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，营业执照已识别成功')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 根据卡BIN获取对应的银行名称(无token)
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/activation/credit/no/token/bank/card/bin/query'
json = {
		  "bankCardNo": BankCardNo,
		  "applyNo": applyNo,
		  "processType": "02",
		  "timestamp": 1779418642266
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	bankCode = b1['body']['bankCode']							# 308584000013
	bankName = b1['body']['bankName']							# 招商银行
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取对应银行名称为:{bankName}')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 获取节点详情(无token)
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/node/no/token/node/detail/query'
json = {
		  "customerType": "01",
		  "applyNo": applyNo,
		  "processType": "02",
		  "businessType": "02",
		  "customerNo": borrowerId,
		  "timestamp": 1779418513955
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	businessNo = b1['body']['businessNo']						# GC20260522105514100007806
	businessType = b1['body']['businessType']					# 02
	currentNode = b1['body']['currentNode']						# XXCJ
	customerNo = b1['body']['customerNo']						# BI6a0fc578d5de4f9e457d580b
	customerType = b1['body']['customerType']					# 01
	projectId = b1['body']['projectId']							# scp0015131989
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取当前节点详情:{currentNode}')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()


# 根据节点暂存接口(无token)
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/node/no/token/node/save'
json = {
		  "businessNo": businessNo,
		  "applyNo": applyNo,
		  "processType": "02",
		  "nodeType": currentNode,
		  "informationCollectionInfo": {
		    "businessLicenseInfo": {
		      "authSerialNo": authSerialNo,
		      "businessLicenseKey": businessLicenseKey,
		      "socialCreditCode": socialCreditCode,
		      "enterpriseName": enterpriseName
		    },
		    "cardInfoEvent": {
		      "bankCode": bankCode,
		      "bankCardNo": BankCardNo,
		      "bankName": bankName
		    },
		    "legalIdentifyInfo": {
		      "idCardBackOcrSerialNo": idCardBackOcrSerialNo,
		      "idCardFrontKey": idcardFrontKey,
		      "idCardNo": idCardNo,
		      "taxationFlag": 1,
		      "idCardBackKey": idcardBackKey,
		      "userName": userName,
		      "effectiveDate": effectiveDate,
		      "idCardFrontOcrSerialNo": idCardFrontOcrSerialNo,
		      "expirationDate": expirationDate
		    }
		  },
		  "timestamp": 1779418985115
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):		
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已暂存身份证、营业执照以及银行卡信息')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

# 信息采集上传(无token)
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/credit/apply/information/collect/submit'
json = {
		  "businessNo": businessNo,
		  "applyNo": applyNo,
		  "processType": "02",
		  "timestamp": 1779418985420
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，信息采集已上传')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

sys.exit()
# 账户短信验证码发送(无-token)	
url = env.wxsbank_supplychain_pcl_partner+'/wxsbank-supplychain-pcl-web/account/no/token/sms/send'
json = {
		  "phone": phone,
		  "idCardNo": idCardNo,
		  "applyNo": applyNo,
		  "processType": "02",
		  "rid": "20260522140937883de9eb3693f4513a",			# 滑块验证码
		  "businessType": "5",
		  "projectId": projectId,
		  "username": username,
		  "timestamp": 1779430180247
		}
a1 = requests.post(url=url,json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
	smsSendSerialNo = b1['body']['smsSendSerialNo']
	StepNum += 1	
	print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已给{phone}发送短信验证码')
else:
	print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
	print_current_line_number()
	print(url)
	print(json)
	print(b1)
	print('*'*50+'END'+'*'*50)
	sys.exit()

