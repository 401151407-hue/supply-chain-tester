# 能良账e融
# 从H5支付

import os
import sys
import time
import requests
from datetime import datetime

current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import get_environment
from utils import query_customer_full_info

# ==============================
#  可配置项（统一在这里修改）
# ==============================
current_env               = 'UAT'                         # 环境：SIT / UAT
social_credit_code        = 'J0078317T1UK6JUQ8E'          # 借款人证件号
enable_discount           = True                          # 是否参与贴息
discount_interest_type    = '1'                           # 贴息方式，0按天,1按金额,3按利率
discount_interest_amount  = 1000                          # 贴息金额
discount_interest_days    = ''                            # 贴息天数
discount_rate             = ''                            # 贴息利率
activity_id               = 139                           # 活动编号
loan_term                 = 100                           # 贷款期限（天）

# ==============================
#  可配置项结束（统一在这里修改）
# ==============================

# 给变量赋予初始值，均为None
phone        = None                                                                        # 登录手机号
union_token  = None                                                                        # 联合登录Token

# 环境配置
env = get_environment(current_env)
if env is None:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print('环境选择错误')
    print('*'*50+'END'+'*'*50)
    sys.exit()

StepNum = 0

# ===== 1. 根据社会信用代码查询完整客户信息 =====
corp_info = query_customer_full_info(social_credit_code, env=current_env)
if corp_info:
    StepNum += 1    
    print(f'企业名称:     {corp_info["enterprise_name"]}')
    print(f'法人名称:     {corp_info["legal_person_name"]}')
    print(f'手机号:       {corp_info["register_phone"]}')
    print(f'项目ID:       {corp_info["project_id"]}')
    print(f'项目名称:     {corp_info["project_name"]}')
    print(f'平台ID:       {corp_info["partner_platform_id"]}')
    print(f'平台名称:     {corp_info["partner_platform_name"]}')
    phone = corp_info["register_phone"]

    # 检查必要变量是否获取成功
    missing = []
    if not phone:
        missing.append('手机号(register_phone)')
    if not corp_info["partner_platform_id"]:
        missing.append('平台ID(partner_platform_id)')
    if not corp_info["project_id"]:
        missing.append('项目ID(project_id)')
    if missing:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(f'缺少以下必要变量: {", ".join(missing)}')
        print('*'*50+'END'+'*'*50)
        sys.exit()

    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已查询完整客户信息')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(f'未找到社会信用代码对应的企业: {social_credit_code}')
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 2. 联合登录，获取Token =====
url = f'{env.wxsbank_supplychain_partner}/wxsbank-supplychain-partner/user/federated/login'
json = {
    'phone': phone,                                                     # 登录手机号（从数据库获取）
    'urlChannelType': '02',                                             # 渠道类型
    'partnerPlatformId': corp_info["partner_platform_id"],              # 平台ID（从数据库获取）
    'returnUrl': '11111',                                               # 回调地址
    'projectId': corp_info["project_id"],                               # 项目ID（从数据库获取）
}
a1 = requests.post(url=url, json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
    login_path = b1['body']['loginPath']
    union_token = login_path.split('token=')[1].split('&')[0]
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，联合登录成功，已获取Token:{union_token}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 3. 查询钱包和授信信息 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/enterprise/query/queryWalletAndCreditInfo'
json = {
    'socialCreditCode': social_credit_code,
    'projectId': corp_info["project_id"],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if 'respCode' not in b1:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(f'接口返回格式异常: {b1}')
    print('*'*50+'END'+'*'*50)
    sys.exit()
if b1['respCode'] == str(10000):
    body = b1['body']
    grant = body.get('grantCreditObj', {}) or {}
    wallet = body.get('walletObj', {}) or {}

    # 枚举转中文
    audit_status_map = {'00': '未审批', '01': '审批中', '02': '审批通过'}
    linked_status_map = {'A': '已绑定', 'N': '未绑卡', 'P': '待验证'}
    repay_type_map = {'1': '等额本息', '2': '等额本金', '3': '一次性还本付息', '4': '定期付息，到期还本'}

    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已查询钱包和授信信息，客户信息状态:{audit_status_map.get(body.get("enterpriseAuditStatus", ""), body.get("enterpriseAuditStatus"))}，企业名称:{grant.get("enterpriseName")}，额度到期日:{grant.get("maturityDate")}，贷款年化利率:{grant.get("annualInterestRate")}%，还款方式:{repay_type_map.get(grant.get("repaymentType", ""), grant.get("repaymentType"))}，钱包账户:{wallet.get("accountNo")}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 4. 查询待支付/待还款订单数量 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/wallet/unPaidAndUnRepaid/orderNum'
json = {
    'timeday': 7,
    'socialCreditCode': social_credit_code,
    'projectId': corp_info["project_id"],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    body = b1['body']
    unPaidOrderNum = body['unPaidOrderNum']
    unRepaidOrderNum = body['unRepaidOrderNum']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，待支付订单:{unPaidOrderNum}笔，待还款订单:{unRepaidOrderNum}笔')
    if unPaidOrderNum == 0:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print('待支付订单数量为0，流程终止')
        print('*'*50+'END'+'*'*50)
        sys.exit()
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()
# ===== 5. 查询待支付订单列表 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/order/list/query'
json = {
    'pageSize': 10,
    'pageNum': 1,
    'socialCreditCode': social_credit_code,
    'sortFlag': 0,
    'projectId': corp_info["project_id"],
    'allowQueryRefinanceUnPayFlag': 0,
    'tradeStatusList': ['01'],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    order_list = b1['body']['orderList']
    if order_list:
        order = order_list[0]
        sub_order_no = order['orderNo']
        credit_amount = order['payAmount']
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取待支付订单，订单编号:{order["orderNo"]}，订单金额:{order["orderAmount"] / 100:.2f}元，支付金额:{order["payAmount"] / 100:.2f}元')
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print('未查询到待支付订单')
        print('*'*50+'END'+'*'*50)
        sys.exit()
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 6. 推送贴息白名单 =====
if enable_discount:
    url = f'{env.wxsbank_supplychain_product_partner}/wxsbank-supplychain-product-partner/activity/whiteList/push'
    json = {
        'subOrderNo': sub_order_no,
        'projectId': corp_info["project_id"],
        'discountInterestType': discount_interest_type,                     # 贴息方式
        'discountInterestAmount': discount_interest_amount,                  # 贴息金额
        'discountRate': discount_rate,                                       # 贴息利率
        'discountAccNo': '',
        'discountAccName': '',
        'discountInterestDays': discount_interest_days,                      # 贴息天数
        'fileType': '02',
    }
    a1 = requests.post(url=url, json=json)
    try:
        b1 = a1.json()
    except:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(f'贴息白名单推送接口返回非JSON，HTTP状态码:{a1.status_code}')
        print(f'请求URL: {url}')
        print(f'返回内容: {a1.text[:500]}')
        print('*'*50+'END'+'*'*50)
        sys.exit()
    if b1['respCode'] == str(10000):
        discount_type_map = {'0': '按天', '1': '按金额', '3': '按利率'}
        discount_type_cn = discount_type_map.get(discount_interest_type, discount_interest_type)
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，贴息白名单推送成功，贴息方式:{discount_type_cn}', end='')
        if discount_interest_type == '1':
            print(f'，贴息金额:{discount_interest_amount}')
        elif discount_interest_type == '0':
            print(f'，贴息天数:{discount_interest_days}')
        elif discount_interest_type == '3':
            print(f'，贴息利率:{discount_rate}')
        else:
            print()
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(b1)
        print('*'*50+'END'+'*'*50)
        sys.exit()
    
    # ===== 7. 参加贴息活动 =====
    url = f'{env.wxsbank_supplychain_adam}/wxsbank-supplychain-adam/activity/discountInterest/join'
    json = {
        'activityId': activity_id,                                          # 活动编号
        'businessNo': sub_order_no,                                         # 业务编号
        'creditAmount': credit_amount,                                      # 借款金额（分）
        'loanTerm': loan_term,                                              # 贷款期限
        'screen': '01',                                                     # 场景编号
    }
    a1 = requests.post(url=url, json=json)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，参加贴息活动成功')
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(b1)
        print('*'*50+'END'+'*'*50)
        sys.exit()

# ===== 8. 查询合同列表 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocolList/query'
json = {
    'subOrderNo': sub_order_no,
    'screenType': '06',
    'socialCreditCode': social_credit_code,
    'projectId': corp_info["project_id"],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    protocol_list = b1['body']['protocolList']
    factoring_contract = None
    other_contracts = []
    for p in protocol_list:
        if p['templateCode'] == 'JJPZMFYZBL001':
            factoring_contract = p
        else:
            other_contracts.append(p)
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取合同列表，共{len(protocol_list)}份')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 9. 查询保理融资合同 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/protocol/iouContract/query'
json = {
    'orderNo': sub_order_no,
    'screenType': '06',
    'loanAmount': credit_amount,
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，保理融资合同已生成，文件:{b1["body"]["fileName"]}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 10. 生成其余合同 =====
for contract in other_contracts:
    url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/signatrue/view/common/contract'
    json = {
        'queryJson': {'subOrderNo': sub_order_no, 'creditAmount': credit_amount},
        'screenType': '06',
        'templateCode': contract['templateCode'],
        'socialCreditCode': social_credit_code,
        'projectId': corp_info["project_id"],
        'timestamp': int(time.time() * 1000),
    }
    a1 = requests.post(url=url, json=json, headers={'token': union_token})
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，合同已生成，文件:{b1["body"]["fileName"]}')
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(b1)
        print('*'*50+'END'+'*'*50)
        sys.exit()

# ===== 11. 获取键盘密钥 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/keyboard/key/query'
json = {
    'uniqueCode': '1f20560d-12b2-4a8d-8901-981ff65bd0f5',
    'socialCreditCode': social_credit_code,
    'projectId': corp_info["project_id"],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    keyboard_key_name = b1['body']['keyboardKeyName']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取键盘密钥:{keyboard_key_name}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 12. 支付订单 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/payment/order/pay'
json = {
    'password': 'g7qOHpziQF3q4/Vd+ndLJO+lNXISTfcioLsYo1dcHoPlJMJtJoEUpYaKmYQVO9gH16NBbvtSrigd9gt10gD9/RLSDcgowqt4UkBqwXrhjZ14Qt1p0GmVqaRtx/HdOm1/upga9jTCG+9PEHGd3+XC3Q==',                                           # 支付密码
    'orderNo': sub_order_no,                                            # 订单编号
    'balancePaymentAmount': '0',                                        # 余额支付金额
    'couponNo': '',                                                     # 优惠券编号
    'keyboardKeyName': keyboard_key_name,                               # 键盘密钥名
    'creditPaymentAmount': str(credit_amount),                          # 授信支付金额
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，支付成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 13. 保存在线签约记录 =====
url = f'{env.wxsbank_supplychain_web}/wxsbank-supplychain-web/online/sign/log/record/save'
json = {
    'agreementList': '《保理融资合同》,《债权转让通知书》,《应收账款转让申请书》',
    'socialCreditCode': social_credit_code,
    'projectId': corp_info["project_id"],
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers={'token': union_token})
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，在线签约记录保存成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()