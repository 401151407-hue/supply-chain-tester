# 能良账e融
# 用信审批（UI自动化）

import os
import re
import sys
import time
from datetime import datetime
from playwright.sync_api import sync_playwright

current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import get_environment
from utils.cmp_config import DEFAULT_USERNAME, DEFAULT_PASSWORD, get_cmp_account

# ==============================
#  可配置项（统一在这里修改）
# ==============================
current_env    = 'SIT'                                                          # 环境：SIT / UAT
search_company  = '蒋敏捷科技公司'                                                  # 借款人企业
# ==============================
#  可配置项结束（统一在这里修改）
# ==============================
# 给变量赋予初始值，均为None

# ===== 截图路径 =====
script_name = os.path.splitext(os.path.basename(__file__))[0]
run_timestamp = datetime.now().strftime('%H%M%S')
date_dir = os.path.join(current_dir, script_name, datetime.now().strftime('%Y-%m-%d'))
success_dir = os.path.join(date_dir, f'{run_timestamp}_成功')
fail_dir = os.path.join(date_dir, f'{run_timestamp}_失败')
os.makedirs(success_dir, exist_ok=True)
os.makedirs(fail_dir, exist_ok=True)

def take_screenshot(page_obj, step_desc, is_fail=False):
    """截图并保存，成功静默保存，失败则打印路径"""
    suffix = '_失败' if is_fail else '_成功'
    filename = f'{step_desc}{suffix}.png'
    filepath = os.path.join(success_dir, filename)
    page_obj.screenshot(path=filepath)
    if is_fail:
        fail_path = os.path.join(fail_dir, filename)
        page_obj.screenshot(path=fail_path)
        print(f'  失败截图: {fail_path}')
    return filepath

# 环境配置
env = get_environment(current_env)
if env is None:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print('环境选择错误')
    print('*'*50+'END'+'*'*50)
    sys.exit()

StepNum = 0

# ===== 1. 启动浏览器 =====
playwright = sync_playwright().start()
browser = playwright.chromium.launch(headless=False)                             # headless=True 可无界面运行
page = browser.new_page()
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，浏览器已启动')
take_screenshot(page, f'第{StepNum}步_浏览器启动')

# ===== 2. 打开审批系统并用默认账号（王泽波）登录 =====
page.goto(env.cmp_url)
page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已打开审批系统登录页')
take_screenshot(page, f'第{StepNum}步_打开登录页')

# 使用默认账号（王泽波）登录
page.fill('input[placeholder*="账号"], input[type="text"]', DEFAULT_USERNAME)
page.fill('input[type="password"]', DEFAULT_PASSWORD)
page.click('button:has-text("登录"), button:has-text("登 录")')
page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，使用默认账号{DEFAULT_USERNAME}登录成功')
take_screenshot(page, f'第{StepNum}步_登录成功')

# ===== 3. 进入链接中心，点击供应链综合管理平台 =====
with page.context.expect_page() as new_page_info:
    page.click('text=供应链综合管理平台')
new_page = new_page_info.value
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已进入供应链综合管理平台')
take_screenshot(new_page, f'第{StepNum}步_进入综合管理平台')

# ===== 4. 展开审批管理，点击用信管理 =====
new_page.click('text=审批管理')
new_page.wait_for_timeout(500)
new_page.click('text=用信管理')
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已进入用信管理')
take_screenshot(new_page, f'第{StepNum}步_进入用信管理')

# ===== 5. 搜索企业并查询 =====
# 点击企业名称标签
new_page.click('.el-form-item:has-text("企业名称") .el-input__inner')
new_page.wait_for_timeout(300)
# 输入客户名称
new_page.fill('.el-form-item:has-text("企业名称") .el-input__inner', search_company)
new_page.wait_for_timeout(1000)
# 点击下拉框中的匹配项
new_page.locator(f'span:has-text("{search_company}")').last.click()
new_page.wait_for_timeout(300)
# 点击查询按钮
new_page.locator('button:has-text("查询"):not(:has-text("重置"))').click()
new_page.wait_for_load_state('networkidle')
# 等待搜索结果表格中出现企业名称，确认数据已刷新
new_page.wait_for_selector(f'.el-table__body:has-text("{search_company}")', timeout=10000)
new_page.wait_for_timeout(500)
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已搜索{search_company}并查询')
take_screenshot(new_page, f'第{StepNum}步_搜索并查询')

# ===== 6. 判断搜索结果是否有数据 =====
# 从分页信息获取总数，避免只统计当前页
pagination_text = new_page.locator('.el-pagination__total').first.inner_text()
match = re.search(r'共\s*(\d+)\s*条', pagination_text)
total_rows = int(match.group(1)) if match else new_page.locator('.el-table__body tr').count()
if total_rows == 0:
    take_screenshot(new_page, f'第{StepNum+1}步_查询无结果', is_fail=True)
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(f'未查询到{search_company}的用信审批数据')
    print('*'*50+'END'+'*'*50)
    browser.close()
    playwright.stop()
    sys.exit()
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，查询到{total_rows}条用信审批记录')
take_screenshot(new_page, f'第{StepNum}步_查询结果{total_rows}条')

# ===== 7. 点击第一条记录的详情按钮 =====
new_page.locator('xpath=//*[@id="app"]/div/div[2]/section/div/div[2]/div[1]/div[4]/div[2]/table/tbody/tr[1]/td[14]/div/button/span').click()
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已点击最新一条详情')
take_screenshot(new_page, f'第{StepNum}步_打开详情')

# ===== 8. 点击审批流程 =====
new_page.click('text=审批流程')
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已点击审批流程')
take_screenshot(new_page, f'第{StepNum}步_审批流程')

# ===== 9. 获取当前操作人 =====
operator_text = new_page.locator('.el-table__body tr').last.locator('td').first.inner_text()
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，当前操作人:{operator_text}')
take_screenshot(new_page, f'第{StepNum}步_当前操作人{operator_text}')

# ===== 10. 退出当前账号 =====
new_page.hover('.el-dropdown, .user-info, .avatar, [class*="user"], [class*="header"] .el-dropdown')
new_page.wait_for_timeout(500)
new_page.click('text=退出')
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已退出当前账号')
take_screenshot(new_page, f'第{StepNum}步_退出成功')

# ===== 11. 根据操作人获取对应账号并重新登录 =====
account = get_cmp_account(operator_text)
if account is None:
    take_screenshot(new_page, f'第{StepNum+1}步_操作人无对应账号', is_fail=True)
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(f'未找到操作人 {operator_text} 对应的审批账号，请在 utils/cmp_config.py 的 OPERATOR_ACCOUNTS 中添加')
    print('*'*50+'END'+'*'*50)
    browser.close()
    playwright.stop()
    sys.exit()

new_page.fill('input[placeholder*="账号"], input[type="text"]', account['username'])
new_page.fill('input[type="password"]', account['password'])
new_page.click('button:has-text("登录"), button:has-text("登 录")')
new_page.wait_for_load_state('networkidle')
StepNum += 1
print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已用操作人账号 {account["username"]} 重新登录')
take_screenshot(new_page, f'第{StepNum}步_操作人登录成功')

# ===== 保持浏览器不关闭，按回车退出 =====
input('\n按回车关闭浏览器...')

# ===== 清理 =====
browser.close()
playwright.stop()
