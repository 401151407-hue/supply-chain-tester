# 能良账e融
# 签署《买方付息承诺函》
# 国联账e融项目配置是卖方付息，所以不需要签署，不需要执行此脚本

import os
import sys
import time
import requests
from datetime import datetime

current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import get_environment

# ==============================
#  可配置项（统一在这里修改）
# ==============================
current_env = 'UAT'              # 环境：SIT / UAT
phone       = '13447799375'      # 手机号，请输入买方手机号
# ==============================
#  可配置项结束（统一在这里修改）
# ==============================                                

# 给变量赋予初始值，均为None
token             = None                                                                # 登录Token
projectId         = None                                                                # 项目ID
socialCreditCode  = None                                                                # 统一社会信用代码
business_no       = None                                                                # 业务编号
faceApplyNo       = None                                                                # 人脸申请编号
identify_flag     = None                                                                # 采集标识
identify_token    = None                                                                # 采集Token
cySerialNo        = None                                                                # 采集流水号

# 环境配置
env = get_environment(current_env)
if env is None:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print('环境选择错误')
    print('*'*50+'END'+'*'*50)
    sys.exit()

StepNum = 0

# ===== 1. 登录门户，获取Token =====
login_url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/user/login'
json = {
    'keyboardKey': 'SCP.728314e0-4fc9-4b67-87b5-c7b797319e8d.sm2',
    'loginPassword': '36aEgBnNS/VkZLhx3f/r73M369IGJ0p6J6l7QwLnHhuMVgTjsQugeyxToPl62nmEIm3TjTNehWagMX+/OP4WrsZqk/J+2JnxHDpJSh0KkK0zieKx1vjMbbuV1LEsHsx46kWqtqfU2LUteN54240pRA==',
    'loginKeyboardKeyName': 'SCP.728314e0-4fc9-4b67-87b5-c7b797319e8d.sm2',
    'businessType': '5',
    'phoneNo': phone,
}
a1 = requests.post(url=login_url, json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
    token = b1['body']['token']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，登录成功，已获取Token')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

headers = {'token': token, 'appId': 'supplyChainPortal'}

# ===== 2. 获取客户信息，提取项目ID和社会信用代码 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cust/info'
json = {'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    projectId = b1['body']['projectId']
    socialCreditCode = b1['body']['socialCreditCode']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取客户信息，项目ID:{projectId}，社会信用代码:{socialCreditCode}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 3. 查询待办任务，判断是否有待签署回执 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cust/todo/task'
json = {'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    task_list = b1['body']
    target_task = None
    for task in task_list:
        if task.get('taskDescribe') == '您有国联账e融项目的《买方付息承诺函》待签署':
            target_task = task
            break
    if target_task:
        business_no = target_task['businessNo']
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取待签署《买方付息承诺函》，业务编号:{business_no}')
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print('未找到待签署的《买方付息承诺函》任务')
        print('*'*50+'END'+'*'*50)
        sys.exit()
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 4. 查询待签署合同列表 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/query/contract/info'
json = {'screen': '46', 'socialCreditCode': socialCreditCode, 'projectId': projectId, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    contract_list = b1['body']['listContrat']
    contract_count = len(contract_list)
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取待签署合同列表，共{contract_count}份')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 5. 逐份签署合同 =====
for i, contract in enumerate(contract_list, 1):
    subOrderNo = contract['subOrderNo']
    templateCode = contract['templateCode']
    url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/view/zer/pay/approve/success/contract'
    json = {'subOrderNo': subOrderNo, 'templateCode': templateCode, 'timestamp': int(time.time() * 1000)}
    a1 = requests.post(url=url, json=json, headers=headers)
    b1 = a1.json()
    if b1['respCode'] == str(10000):
        StepNum += 1
        print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，第{i}/{contract_count}份合同签署成功，子订单号:{subOrderNo}')
    else:
        print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
        print(f'第{i}份合同签署失败')
        print(b1)
        print('*'*50+'END'+'*'*50)
        sys.exit()

# ===== 6. 生成人脸识别二维码 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/qrcode/generate'
json = {'cyType': 'ZER_PAY_SCREEN', 'businessNo': business_no, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    faceApplyNo = b1['body']['faceApplyNo']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已生成人脸识别二维码，人脸申请编号:{faceApplyNo}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 7. 获取采集标识 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cyIdentify/generate/flag'
json = {'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    identify_flag = b1['body']['flag']
    identify_token = b1['body']['token']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取采集标识，flag:{identify_flag}，token:{identify_token}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 8. 提交视频活体检测 =====
video_key = 'supplychain/CY/2026-06-05/20260605162121224614033abe1bf27c6a991382d5f7da3d7680e29.mov'
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cyIdentify/video/liveness'
json = {
    'cyType': 'ZER_PAY_SCREEN',
    'flag': identify_flag,
    'faceApplyNo': faceApplyNo,
    'videoKey': video_key,
    'token': identify_token,
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    cySerialNo = b1['body']['cySerialNo']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，视频活体检测提交成功，采集流水号:{cySerialNo}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 9. 唇语识别/动作识别校验结果 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cyIdentify/verify'
json = {
    'cyType': 'ZER_PAY_SCREEN',
    'businessNo': business_no,
    'faceApplyNo': faceApplyNo,
    'cySerialNo': cySerialNo,
    'timestamp': int(time.time() * 1000),
}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，唇语识别/动作识别校验结果成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 10. 检测人脸识别结果 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/qrcode/querycheck'
json = {'cyType': 'ZER_PAY_SCREEN', 'businessNo': business_no, 'faceApplyNo': faceApplyNo, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，人脸识别检测完成')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()
