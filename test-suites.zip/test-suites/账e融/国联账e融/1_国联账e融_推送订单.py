# 国联账e融
# 推送订单
# 上传应收账款Excel到门户并完成后续流程

import os
import sys
import time
import requests
from datetime import datetime
import openpyxl
import random
import string

current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils import get_environment

# ==============================
#  可配置项（统一在这里修改）
# ==============================
current_env = 'UAT'                                 # 环境：SIT / UAT
phone       = '13447799375'                         # 手机号，国联合作方，需要登录门户导入订单的手机号
CONFIG = {
    "企业名称": "宋永萍科技公司",                       # 借款人企业，请输入借款方企业名称
    "统一社会信用代码": "J0078317T1UK6JUQ8E",          # 借款人证件号，请输入借款方企业的统一社会信用代码
    "买方企业名称": "于洪芳科技",                       # 买方名称，请输入买方的企业名称
    "买方统一社会信用代码": "Q9518213ATNKQRBUEX",       # 买方证件号，请输入买方企业的统一社会信用代码
}                                                    
# ==============================
#  可配置项结束（统一在这里修改）
# ==============================                                                    
# 上上层目录
grand_parent = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# 拼接完整文件路径
file_path = os.path.join(grand_parent, "config", "国联账e融导入模板-应收账款.xlsx")
# 打包成 exe 后，优先使用 exe 同目录下的 config/（方便用户手动修改模板）
if getattr(sys, 'frozen', False):
    _exe_dir = os.path.dirname(sys.executable)
    _ext_file = os.path.join(_exe_dir, "config", "国联账e融导入模板-应收账款.xlsx")
    if os.path.exists(_ext_file):
        file_path = _ext_file
expected_project_name = '国联账e融'                  # 预期项目名称

# 读取本地 Excel 文件
wb = openpyxl.load_workbook(file_path)

# =====================================================
# 写入可配置项到应收账款信息Sheet
# =====================================================
ws_receivable = wb["应收账款信息"]
ws_receivable["A4"].value = CONFIG["企业名称"]
ws_receivable["B4"].value = CONFIG["统一社会信用代码"]
ws_receivable["O4"].value = CONFIG["买方企业名称"]
ws_receivable["N4"].value = CONFIG["买方统一社会信用代码"]
print(f"应收账款信息!A4 -> {CONFIG['企业名称']}")
print(f"应收账款信息!B4 -> {CONFIG['统一社会信用代码']}")
print(f"应收账款信息!O4 -> {CONFIG['买方企业名称']}")
print(f"应收账款信息!N4 -> {CONFIG['买方统一社会信用代码']}")

# 已记住的订单号单元格位置（写入相同的随机订单号）
order_cells = [
    ("应收账款信息", "C4"),
    ("合同信息", "A4"),
]

# 生成一个相同的随机订单号
new_order = "LCLGL" + "".join(random.choices(string.digits, k=11))
print(f"开始组装随机订单号: {new_order}")

for sheet_name, cell_ref in order_cells:
    ws = wb[sheet_name]
    ws[cell_ref].value = new_order
    # print(f"  {sheet_name}!{cell_ref} -> {new_order}")

# =====================================================
# 先读取合同信息!B4的值，再全局搜索所有Sheet页中与其相同的值，统一替换
# =====================================================
# 第一步：读取合同信息!B4
ws_contract = wb["合同信息"]
source_value = ws_contract["B4"].value
# print(f"\n合同信息!B4 当前值: {source_value}")

if source_value is not None:
    # 第二步：全局搜索所有Sheet页中与B4相同的值
    contract_positions = []

    # print(f"--- 全局搜索: {source_value} ---")
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if cell.value == source_value:
                    pos = f"{ws.title}!{cell.coordinate}"
                    contract_positions.append(pos)
                    # print(f"  找到: {pos}")

    # 第三步：生成统一的随机合同编号，全部替换
    new_contract = "LCLGLMYHT" + "".join(random.choices(string.digits, k=10))
    print(f"开始组装随机合同编号: {new_contract}")

    for pos in contract_positions:
        sheet_name, cell_ref = pos.split("!")
        ws = wb[sheet_name]
        ws[cell_ref].value = new_contract
        # print(f"  {pos} -> {new_contract}")

    # print(f"\n共替换 {len(contract_positions)} 个合同编号单元格")
else:
    print("合同信息!B4 为空，跳过合同编号替换")

# 保存文件（如被Excel占用请先关闭Excel）
wb.save(file_path)
print(f"\n导入模板已组装完成，文件已保存: {file_path}")
wb.close()

# 给变量赋予初始值，均为None
token     = None                                                                        # 登录Token
file_key  = None                                                                        # 上传后的文件key
order_id  = None                                                                        # 订单ID
order_no  = None                                                                        # 合作方订单号

# 环境配置
env = get_environment(current_env)
if env is None:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print('环境选择错误')
    print('*'*50+'END'+'*'*50)
    sys.exit()

if not os.path.exists(file_path):
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，文件不存在: {file_path}')
    sys.exit(1)

StepNum = 0

# ===== 1. 登录门户，获取Token =====
login_url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/user/login'
json = {
    'keyboardKey': 'SCP.728314e0-4fc9-4b67-87b5-c7b797319e8d.sm2',
    'loginPassword': '36aEgBnNS/VkZLhx3f/r73M369IGJ0p6J6l7QwLnHhuMVgTjsQugeyxToPl62nmEIm3TjTNehWagMX+/OP4WrsZqk/J+2JnxHDpJSh0KkK0zieKx1vjMbbuV1LEsHsx46kWqtqfU2LUteN54240pRA==',
    'loginKeyboardKeyName': 'SCP.728314e0-4fc9-4b67-87b5-c7b797319e8d.sm2',
    'businessType': '5',
    'phoneNo': phone,
}
a1 = requests.post(url=login_url, json=json)
b1 = a1.json()
if b1['respCode'] == str(10000):
    token = b1['body']['token']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，登录成功，已获取Token')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

headers = {'token': token, 'appId': 'supplyChainPortal'}

# ===== 2. 获取客户信息，校验项目名称 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/cust/info'
json = {'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    projectId = b1['body']['projectId']
    projectName = b1['body']['projectName']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取客户信息，项目ID:{projectId}，项目名称:{projectName}')
    if projectName != expected_project_name:
        # 当前项目不匹配，查询可切换项目列表
        url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/switchable/project/list'
        json = {'timestamp': int(time.time() * 1000)}
        a1 = requests.post(url=url, json=json, headers=headers)
        b1 = a1.json()
        if b1['respCode'] == str(10000):
            project_list = b1['body']
            found = None
            for p in project_list:
                if p['projectName'] == expected_project_name:
                    found = p
                    break
            if found:
                projectId = found['projectId']
                projectName = found['projectName']
                # 切换项目
                url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/switch/project'
                json = {'projectId': projectId, 'timestamp': int(time.time() * 1000)}
                a1 = requests.post(url=url, json=json, headers=headers)
                b1 = a1.json()
                if b1['respCode'] == str(10000):
                    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已切换至项目:{projectName}，项目ID:{projectId}')
                else:
                    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
                    print(b1)
                    print('*'*50+'END'+'*'*50)
                    sys.exit()
            else:
                print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
                print(f'可切换项目列表中未找到项目:{expected_project_name}')
                print(f'可用项目: {", ".join(p["projectName"] for p in project_list)}')
                print('*'*50+'END'+'*'*50)
                sys.exit()
        else:
            print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
            print(b1)
            print('*'*50+'END'+'*'*50)
            sys.exit()
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 3. 上传文件 =====
file_name = os.path.basename(file_path)
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/singleFile/upload'
with open(file_path, 'rb') as f:
    files = {'file': (file_name, f, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
    a1 = requests.post(url=url, files=files, data={'fileType': 'ORDER'}, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    file_key = b1['body']['fileKey']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，文件上传成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 4. 批量导入 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/order/nl/batch/import'
json = {'fileKey': file_key, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，批量导入成功')    
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 5. 查询推送订单列表，获取最新订单ID =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/order/nl/order/push/list/query'
json = {'pageSize': 10, 'pageNum': 1, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    page_list = b1['body']['pageList']
    order_id = page_list[0]['id']
    order_no = page_list[0]['partnerOrderNo']
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，已获取最新订单ID:{order_id}，合作方订单号:{order_no}')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 6. 基础合同导入 =====
contract_file_key = 'supplychain/ORDER/2026-06-05/20260605144259686644455夏建军反面.jpg'
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/order/nl/basic/contract/import'
json = {'fileKey': contract_file_key, 'id': order_id, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，基础合同导入成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()

# ===== 7. 推送订单详情 =====
url = f'{env.wxsbank_supplychain_portal_web}/wxsbank-supplychain-portal-web/order/nl/push/order/detail'
json = {'id': order_id, 'timestamp': int(time.time() * 1000)}
a1 = requests.post(url=url, json=json, headers=headers)
b1 = a1.json()
if b1['respCode'] == str(10000):
    StepNum += 1
    print(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")}，第「{StepNum}」步，订单详情推送成功')
else:
    print('\n\n\n'+'*'*50+'异常信息'+'*'*50)
    print(b1)
    print('*'*50+'END'+'*'*50)
    sys.exit()
